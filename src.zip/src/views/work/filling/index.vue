<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      ref="queryRef"
      :inline="true"
      v-show="showSearch"
      label-width="80px"
    >
      <el-form-item label="作业名称" prop="taskName">
        <el-input
          v-model="queryParams.taskName"
          placeholder="请输入作业名称"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="作业位置" prop="positionId">
        <el-select
          style="width: 215px"
          v-model="queryParams.positionId"
          placeholder="请选择作业位置"
          clearable
          @keyup.enter="handleQuery"
        >
          <el-option
            v-for="item in Allpositions"
            :key="item.positionId"
            :label="item.position"
            :value="item.positionId"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="审核状态" prop="approvalStatus">
        <el-select
          v-model="queryParams.approvalStatus"
          placeholder="请选择审核状态"
          clearable
          style="width: 215px"
        >
          <el-option
            v-for="dict in work_examine_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="作业日期" prop="startTime">
        <el-date-picker
          clearable
          v-model="queryParams.startTime"
          type="date"
          value-format="YYYY-MM-DD"
          placeholder="请选择作业日期"
        >
        </el-date-picker>
      </el-form-item>
      <el-form-item label="风险名" prop="riskId">
        <el-select
          style="width: 215px"
          v-model="queryParams.riskId"
          placeholder="请选择风险名"
          clearable
          @keyup.enter="handleQuery"
        >
          <el-option
            v-for="item in AllrisksName"
            :key="item.riskId"
            :label="item.riskName"
            :value="item.riskId"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="负责人" prop="mandateHolder">
        <el-input
          v-model="queryParams.mandateHolder"
          placeholder="请输入负责人"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          icon="Search"
          color="#03bd8a"
          @click="handleQuery"
          style="text-shadow: 0 0 0.3px #fff"
          >查询</el-button
        >
        <el-button
          icon="Refresh"
          @click="resetQuery"
          style="text-shadow: 0 0 0.3px #606266"
          >重置</el-button
        >
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="2">
        <el-button
          type="primary"
          plain
          icon="Plus"
          color="#03bd8a"
          style="text-shadow: 0 0 0.3px #03bd8a"
          @click="handleAdd"
          v-hasPermi="['system:task:add']"
          >新增</el-button
        > </el-col
      ><el-col :span="3">
        <el-upload
          action=""
          :auto-upload="false"
          :show-file-list="false"
          :on-change="readExcel"
        >
          <el-button
            color="#03bd8a"
            style="text-shadow: 0 0 0.3px #fff"
            icon="DocumentAdd"
            type="primary"
            >Excel批量导入</el-button
          >
        </el-upload>
      </el-col>

      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="Download"
          @click="handleExport"
          v-hasPermi="['system:task:export']"
          >导出</el-button
        >
      </el-col>
      <right-toolbar
        v-model:showSearch="showSearch"
        @queryTable="getList"
      ></right-toolbar>
    </el-row>

    <el-table
      v-loading="loading"
      :data="taskList"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="30" align="center" />
      <el-table-column type="index" label="序号" width="60" align="center" />
      <el-table-column
        width="150"
        label="作业名称"
        align="center"
        prop="taskName"
      />
      <el-table-column
        label="作业时间"
        align="center"
        prop="startTime"
        width="110"
      >
        <template #default="scope">
          <span>{{ parseTime(scope.row.startTime, "{y}-{m}-{d}") }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="截止时间"
        align="center"
        prop="endTime"
        width="110"
      >
        <template #default="scope">
          <span>{{ parseTime(scope.row.endTime, "{y}-{m}-{d}") }}</span>
        </template>
      </el-table-column>
      <el-table-column
        width="160"
        label="作业位置"
        align="center"
        prop="position"
      />
      <el-table-column
        width="170"
        label="风险名"
        align="center"
        prop="riskName"
      />
      <el-table-column
        width="120"
        label="班组"
        align="center"
        prop="deptName"
      />
      <el-table-column
        width="120"
        label="负责人"
        align="center"
        prop="mandateHolder"
      />
      <el-table-column
        width="90"
        label="审核状态"
        align="center"
        prop="approvalStatus"
      >
        <template #default="scope">
          <dict-tag
            :options="work_examine_status"
            :value="scope.row.approvalStatus"
            :style="getApprovalStatusStyles(scope.row.approvalStatus)"
          />
        </template>
      </el-table-column>
      <el-table-column
        label="操作"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            class="editButton"
            color="#06c08b"
            plain
            @click="handleUpdate(scope.row)"
            v-hasPermi="['system:task:edit']"
            >编辑</el-button
          >
          <el-button
            class="DelButton"
            color="#ff7b47"
            plain
            @click="handleDelete(scope.row)"
            v-hasPermi="['system:task:remove']"
            >删除</el-button
          >
        </template>
      </el-table-column>
      <el-table-column
        label="作业详情"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            class="moreButton"
            color="#3b87e0"
            plain
            @click="handleMore(scope.row)"
            >查看详情</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 新增作业对话框 -->
    <el-dialog :title="title" v-model="addOpen" width="650px" append-to-body>
      <span class="Basic">| <span class="Mes">基本信息</span></span>
      <el-form
        ref="taskRef"
        :model="addForm"
        :rules="rules"
        label-width="100px"
        style="margin-top: 20px"
      >
        <el-form-item label="作业名称" prop="taskName">
          <el-input v-model="addForm.taskName" placeholder="请输入作业名称" />
        </el-form-item>
        <el-form-item label="负责人" prop="mandateHolder">
          <el-input
            v-model="addForm.mandateHolder"
            placeholder="请输入负责人"
          />
        </el-form-item>
        <el-form-item label="班组" prop="deptName">
          <el-input v-model="addForm.deptName" placeholder="请输入班组" />
        </el-form-item>
        <el-form-item label="作业位置" prop="positionId">
          <el-select
            v-model="addForm.positionId"
            placeholder="请选择作业位置"
            style="width: 245px"
          >
            <el-option
              v-for="item in Allpositions"
              :key="item.positionId"
              :label="item.position"
              :value="item.positionId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="作业时间" prop="startTime">
          <el-date-picker
            clearable
            v-model="addForm.startTime"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="请选择作业时间"
          >
          </el-date-picker>
        </el-form-item>
        <el-form-item label="截止时间" prop="endTime">
          <el-date-picker
            clearable
            v-model="addForm.endTime"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="请选择截止时间"
          >
          </el-date-picker>
        </el-form-item>

        <el-form-item label="风险名" prop="riskId">
          <el-select
            v-model="addForm.riskId"
            placeholder="请选择风险名"
            clearable
            @keyup.enter="handleQuery"
            style="width: 245px"
          >
            <el-option
              v-for="item in AllrisksName"
              :key="item.riskId"
              :label="item.riskName"
              :value="item.riskId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input
            v-model="addForm.remark"
            type="textarea"
            placeholder="请输入内容"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="addsubmitForm">确 定</el-button>
          <el-button @click="addCancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>

    <!-- 编辑作业对话框 -->
    <el-dialog :title="title" v-model="editOpen" width="650px" append-to-body>
      <span class="Basic">| <span class="Mes">基本信息</span></span>
      <el-form
        ref="taskRef"
        :model="editForm"
        :rules="rules"
        label-width="100px"
        style="margin-top: 20px"
      >
        <el-form-item label="作业名称" prop="taskName">
          <el-input v-model="editForm.taskName" placeholder="请输入作业名称" />
        </el-form-item>
        <el-form-item label="负责人" prop="mandateHolder">
          <el-input
            v-model="editForm.mandateHolder"
            placeholder="请输入负责人"
          />
        </el-form-item>
        <el-form-item label="班组" prop="deptName">
          <el-input v-model="editForm.deptName" placeholder="请输入班组" />
        </el-form-item>
        <el-form-item label="作业位置" prop="positionId">
          <el-select
            v-model="editForm.positionId"
            placeholder="请选择作业位置"
            style="width: 245px"
          >
            <el-option
              v-for="item in Allpositions"
              :key="item.positionId"
              :label="item.position"
              :value="item.positionId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="作业时间" prop="startTime">
          <el-date-picker
            clearable
            v-model="editForm.startTime"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="请选择作业时间"
          >
          </el-date-picker>
        </el-form-item>
        <el-form-item label="截止时间" prop="endTime">
          <el-date-picker
            clearable
            v-model="editForm.endTime"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="请选择截止时间"
          >
          </el-date-picker>
        </el-form-item>
        <el-form-item label="风险级别" prop="riskLevel">
          <el-select
            v-model="editForm.riskLevel"
            placeholder="请选择风险级别"
            style="width: 245px"
          >
            <el-option
              v-for="item in risks"
              :key="item.value"
              :label="item.value"
              :value="item.value"
            >
              <span
                style="
                  float: right;
                  color: var(--el-text-color-secondary);
                  font-size: 15px;
                "
                >{{ item.label }}</span
              >
              <span style="float: left">
                {{ item.value }}
              </span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input
            v-model="editForm.remark"
            type="textarea"
            placeholder="请输入内容"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="editsubmitForm">确 定</el-button>
          <el-button @click="editCancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>

    <!-- 查看作业详情对话框 -->
    <el-dialog v-model="moreOpen" width="800px" append-to-body title="作业详情">
      <span class="Basic">| <span class="Mes">详细信息</span></span>
      <el-descriptions border column="2">
        <el-descriptions-item label="作业名称">{{
          moreform.taskName
        }}</el-descriptions-item>
        <el-descriptions-item label="作业类型">{{
          moreform.typeName
        }}</el-descriptions-item>
        <el-descriptions-item label="班组">{{
          moreform.deptName
        }}</el-descriptions-item>
        <el-descriptions-item label="风险名">{{
          moreform.riskName
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="作业位置">{{
          moreform.position
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="作业描述">{{
          moreform.taskDesc
        }}</el-descriptions-item>
        <el-descriptions-item label="作业时间">{{
          moreform.startTime
        }}</el-descriptions-item>
        <el-descriptions-item label="截止时间">{{
          moreform.endTime
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="负责人">{{
          moreform.mandateHolder
        }}</el-descriptions-item>
        <el-descriptions-item label="审核状态"
          ><el-tag size="small" :style="tagStyle" effect="dark">{{
            approvalStatusText
          }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="审核人">{{
          moreform.reviewer
        }}</el-descriptions-item>
        <el-descriptions-item label="创建人">{{
          moreform.createBy
        }}</el-descriptions-item>
        <el-descriptions-item label="创建时间">{{
          moreform.createTime
        }}</el-descriptions-item>
        <el-descriptions-item label="修改人">{{
          moreform.updateBy
        }}</el-descriptions-item>
        <el-descriptions-item label="修改时间">{{
          moreform.updateTime
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="备注">{{
          moreform.remark
        }}</el-descriptions-item>
      </el-descriptions>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="moreCancel">确 定</el-button>
          <el-button @click="moreCancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Task">
import {
  listTask,
  listRiskAll,
  listPatrolPointAll,
  getTask,
  delTask,
  addTask,
  addTaskExcel,
  updateTask,
  getRiskLibrary,
  getPoint,
} from "@/api/work/fill";
import { ref } from "vue";
import * as XLSX from "xlsx";
const { proxy } = getCurrentInstance();
const { work_examine_status } = proxy.useDict("work_examine_status");

const taskList = ref([]);
const riskId = ref([]);
const risksName = ref([]);
const AllrisksName = ref([]);
const positionId = ref([]);
const positions = ref([]);
const Allpositions = ref([]);

const addOpen = ref(false);
const editOpen = ref(false);
const moreOpen = ref(false);

const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const data = reactive({
  addForm: {},
  editForm: {},
  moreform: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    taskName: null,
    approvalStatus: null,
    startTime: null,
    riskId: null,
    positionId: null,
    mandateHolder: null,
  },
  rules: {
    taskName: [
      { required: true, message: "作业名称不能为空", trigger: "blur" },
    ],
    deptName: [{ required: true, message: "班组不能为空", trigger: "blur" }],
    mandateHolder: [
      { required: true, message: "负责人不能为空", trigger: "blur" },
    ],
    positionId: [
      { required: true, message: "作业位置不能为空", trigger: "blur" },
    ],
  },
});

const { queryParams, addForm, editForm, moreform, rules } = toRefs(data);

const risks = ref([
  {
    value: "A",
    label: "风险最高",
  },
  {
    value: "B",
    label: "B及B以上风险需要审核",
  },
  {
    value: "C",
    label: "风险中等",
  },
  {
    value: "D",
    label: "风险最低",
  },
]);

/** 查询作业填报列表 */
async function getList() {
  loading.value = true;
  try {
    const response = await listTask(queryParams.value);
    taskList.value = response.rows;
    total.value = response.total;
    riskId.value = response.rows.map((row) => row.riskId);
    positionId.value = response.rows.map((row) => row.positionId);
    // 逐一查询风险库
    await queryRiskNamesForIds(riskId.value);
    await queryPositionsForIds(positionId.value);

    risksName.value.sort((a, b) => a.riskId - b.riskId);
    positions.value.sort((a, b) => a.positionId - b.positionId);
    taskList.value.forEach((task) => {
      const riskName = risksName.value.find(
        (name) => name.riskId === task.riskId
      );
      if (riskName) {
        task.riskName = riskName.riskName;
      }
      const position = positions.value.find(
        (name) => name.positionId === task.positionId
      );
      if (position) {
        task.position = position.position;
      }
    });
    loading.value = false;
  } catch (error) {
    console.error("获取任务列表失败:", error);
    loading.value = false;
  }
}
async function getListAll() {
  try {
    const response1 = await listRiskAll();
    AllrisksName.value = response1.rows.map((riskName, riskId) => {
      return {
        riskName: riskName.riskName,
        riskId: riskId + 1,
      };
    });

    const response2 = await listPatrolPointAll();
    Allpositions.value = response2.rows.map((position, positionId) => {
      return {
        position: position.position,
        positionId: positionId + 1,
      };
    });
  } catch (error) {
    console.error("获取列表失败:", error);
    loading.value = false;
  }
}
// 逐一查询风险库并更新 taskList
async function queryRiskNamesForIds(ids) {
  const promises = ids.map(async (id) => {
    const response = await getRiskLibrary(id);
    handleSingleRiskLibraryResponse(response.data, id);
  });
  await Promise.all(promises).catch((errors) =>
    console.error("部分请求失败:", errors)
  );
}
async function queryPositionsForIds(ids) {
  // 过滤掉 undefined、null 和无效值
  const validIds = ids.filter(id => id != null && id !== undefined && id !== '' && !isNaN(id));
  if (validIds.length === 0) {
    return;
  }
  const promises = validIds.map(async (id) => {
    const response = await getPoint(id);
    handleSingleGetPointResponse(response.data, id);
  });

  await Promise.all(promises).catch((errors) =>
    console.error("部分请求失败:", errors)
  );
}
// 处理单个风险库响应数据
function handleSingleRiskLibraryResponse(data, riskIdItem) {
  if (data && data.riskName) {
    const existingRiskIndex = risksName.value.findIndex(
      (item) => item.riskId === riskIdItem
    );
    if (existingRiskIndex === -1) {
      risksName.value.push({ riskId: riskIdItem, riskName: data.riskName });
    } else {
      risksName.value[existingRiskIndex].riskName = data.riskName;
    }
    taskList.value.forEach((task) => {
      if (task.riskId === riskIdItem) {
        task.riskName = data.riskName;
      }
    });
    // const foundTask = taskList.value.find((task) => task.riskId === riskIdItem);
    // if (foundTask) {
    //   foundTask.riskName = data.riskName;
    // }
  }
}
function handleSingleGetPointResponse(data, positionIdItem) {
  if (data && data.position) {
    const existingRiskIndex = positions.value.findIndex(
      (item) => item.positionId === positionIdItem
    );
    if (existingRiskIndex === -1) {
      positions.value.push({
        positionId: positionIdItem,
        position: data.position,
      });
    } else {
      positions.value[existingRiskIndex].position = data.position;
    }
    taskList.value.forEach((task) => {
      if (task.positionId === positionIdItem) {
        task.position = data.position;
      }
    });
  }
}
// 取消按钮
function addCancel() {
  addOpen.value = false;
  addReset();
}
function editCancel() {
  editOpen.value = false;
  editReset();
}
function moreCancel() {
  moreOpen.value = false;
}
// 表单重置
function addReset() {
  addForm.value = {
    id: null,
    taskName: null,
    typeName: null,
    deptName: null,
    startTime: null,
    endTime: null,
    riskName: null,
    mandateHolder: null,
    approvalStatus: null,
    reviewer: null,
    taskDesc: null,
    positionInfo: null,
    createBy: null,
    remark: null,
    createTime: null,
    updateBy: null,
    updateTime: null,
  };
  proxy.resetForm("taskRef");
}
function editReset() {
  editForm.value = {
    id: null,
    taskName: null,
    typeName: null,
    deptName: null,
    startTime: null,
    endTime: null,
    riskName: null,
    mandateHolder: null,
    approvalStatus: null,
    reviewer: null,
    taskDesc: null,
    positionInfo: null,
    createBy: null,
    remark: null,
    createTime: null,
    updateBy: null,
    updateTime: null,
  };
  proxy.resetForm("taskRef");
}
/** 搜索按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
  getListAll();
}

/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// 多选框选中数据
function handleSelectionChange(selection) {
  ids.value = selection.map((item) => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 新增按钮操作 */
function handleAdd() {
  addReset();
  addOpen.value = true;
  title.value = "新增作业";
}

/** 编辑按钮操作 */
function handleUpdate(row) {
  editReset();
  const _id = row.id || ids.value;
  getTask(_id).then((response) => {
    editForm.value = response.data;
    const riskId = response.data.riskId;
    getRiskLibrary(riskId).then((response) => {
      editForm.value.riskLevel = response.data.riskLevel;
    });
    editOpen.value = true;
    title.value = "编辑作业";
  });
}

/** 查看作业详情按钮操作 */
function handleMore(row) {
  const _id = row.id || ids.value;
  getTask(_id).then((response) => {
    moreform.value = response.data;
    const riskId = response.data.riskId;
    const positionId = response.data.positionId;
    getRiskLibrary(riskId).then((response) => {
      moreform.value.riskName = response.data.riskName;
    });
    if (positionId != null && positionId !== undefined && !isNaN(positionId)) {
      getPoint(positionId).then((response) => {
        moreform.value.position = response.data.position;
      });
    }
    moreOpen.value = true;
  });
}

/** 提交按钮 */
function addsubmitForm() {
  addTask(addForm.value).then((response) => {
    proxy.$modal.msgSuccess("新增成功");
    addOpen.value = false;
    getList();
    getListAll();
  });
}
function editsubmitForm() {
  updateTask(editForm.value).then((response) => {
    proxy.$modal.msgSuccess("编辑成功");
    editOpen.value = false;
    getList();
    getListAll();
  });
}

/** 删除按钮操作 */
function handleDelete(row) {
  const _ids = row.id || ids.value;
  proxy.$modal
    .confirm('是否确认删除作业编号为"' + _ids + '"的数据项？')
    .then(function () {
      return delTask(_ids);
    })
    .then(() => {
      getList();

      getListAll();
      proxy.$modal.msgSuccess("删除成功");
    })
    .catch(() => {});
}
// excel导入按钮操作
function readExcel(file) {
  const fileReader = new FileReader();
  fileReader.onload = (e) => {
    try {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const wsname = workbook.SheetNames[0];
      const wx = XLSX.utils.sheet_to_json(workbook.Sheets[wsname]);
      addTaskExcel(wx).then((response) => {
        proxy.$modal.msgSuccess("导入成功");
        getList();
        getListAll();
      });
    } catch (e) {
      console.error(e);
      return false;
    }
  };
  fileReader.readAsArrayBuffer(file.raw);
}
/** 导出按钮操作 */
function handleExport() {
  proxy.download(
    "system/task/export",
    {
      ...queryParams.value,
    },
    `task_${new Date().getTime()}.xlsx`
  );
}

getList();
getListAll();

const getApprovalStatusStyles = (status) => {
  switch (status) {
    case 0:
      return {
        color: "#fb9a29",
        textShadow: "0px 0px 0.3px #fb9a29",
      };
    case 1:
      return {
        color: "#06c08b",
        textShadow: "0px 0px 0.3px #06c08b",
      };
    case 2:
      return {
        color: "#ff1a04",
        textShadow: "0px 0px 0.3px #ff1a04",
      };
    default:
      return {};
  }
};

const tagStyle = computed(() => {
  switch (moreform.value.approvalStatus) {
    case 0:
      return {
        backgroundColor: "#fb9a2922",
        color: "#fb9a29",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #fb9a29",
        fontSize: "13.5px",
      };
    case 1:
      return {
        backgroundColor: "#06c08b22",
        color: "#06c08b",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #06c08b",
        fontSize: "13.5px",
      };
    case 2:
      return {
        backgroundColor: "#ff1a0422",
        color: "#ff1a04",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #ff1a04",
        fontSize: "13.5px",
      };
    default:
      return {
        backgroundColor: "#ff1a0422",
        color: "#ff1a04",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #ff1a04",
        fontSize: "13.5px",
      };
  }
});

const approvalStatusText = computed(() => {
  switch (moreform.value.approvalStatus) {
    case 0:
      return "未审核";
    case 1:
      return "通过";
    case 2:
      return "未通过";
    default:
      return "未知状态";
  }
});
</script>

<style scoped lang="scss">
</style>
