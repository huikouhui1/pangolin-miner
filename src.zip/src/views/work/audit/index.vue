<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      ref="queryRef"
      :inline="true"
      v-show="showSearch"
      label-width="80px"
    >
      <el-form-item label="作业日期" prop="startTime">
        <el-date-picker
          clearable
          v-model="queryParams.startTime"
          type="date"
          value-format="YYYY-MM-DD"
          placeholder="请选择作业日期"
        >
        </el-date-picker>
      </el-form-item>
      <el-form-item label="风险级别" prop="riskLevel">
        <el-select
          clearable
          style="width: 245px"
          v-model="queryParams.riskLevel"
          placeholder="请选择风险级别"
        >
          <el-option
            v-for="item in risksLevel"
            :key="item.value"
            :label="item.value"
            :value="item.value"
          >
            <span
              style="
                float: right;
                color: var(--el-text-color-secondary);
                font-size: 15px;
              "
              >{{ item.label }}</span
            >
            <span style="float: left">
              {{ item.value }}
            </span>
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="审核状态" prop="approvalStatus">
        <el-radio-group v-model="queryParams.approvalStatus">
          <el-radio
            v-for="dict in work_examine_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
            >{{ dict.label }}</el-radio
          >
        </el-radio-group>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          icon="Search"
          color="#03bd8a"
          @click="handleQuery"
          style="text-shadow: 0 0 0.3px #fff"
          >查询</el-button
        >
        <el-button
          icon="Refresh"
          @click="resetQuery"
          style="text-shadow: 0 0 0.3px #606266"
          >重置</el-button
        >
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <right-toolbar
        v-model:showSearch="showSearch"
        @queryTable="getList"
      ></right-toolbar>
    </el-row>

    <el-table
      v-loading="loading"
      :data="auditList"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="30" align="center" />
      <el-table-column label="序号" width="60" align="center" type="index"/>
      <el-table-column
        label="作业名称"
        width="200"
        align="center"
        prop="taskName"
      />
      <el-table-column
        label="作业时间"
        align="center"
        prop="startTime"
        width="110"
      >
        <template #default="scope">
          <span>{{ parseTime(scope.row.startTime, "{y}-{m}-{d}") }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="截止时间"
        align="center"
        prop="endTime"
        width="110"
      >
        <template #default="scope">
          <span>{{ parseTime(scope.row.endTime, "{y}-{m}-{d}") }}</span>
        </template>
      </el-table-column>
      <el-table-column
        width="180"
        label="作业位置"
        align="center"
        prop="position"
      />
      <el-table-column
        width="100"
        label="风险级别"
        align="center"
        prop="riskLevel"
      />
      <el-table-column
        width="120"
        label="班组"
        align="center"
        prop="deptName"
      />
      <el-table-column
        width="120"
        label="负责人"
        align="center"
        prop="mandateHolder"
      />
      <el-table-column
        width="120"
        label="审核状态"
        align="center"
        prop="approvalStatus"
      >
        <template #default="scope">
          <dict-tag
            :options="work_examine_status"
            :value="scope.row.approvalStatus"
            :style="getApprovalStatusStyles(scope.row.approvalStatus)"
          />
        </template>
      </el-table-column>

      <el-table-column
        label="操作"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            plain
            type="primary"
            @click="handleUpdate(scope.row)"
            v-hasPermi="['work:audit:edit']"
            class="auditButton"
            >审核</el-button
          >
        </template>
      </el-table-column>
      <el-table-column
        label="作业详情"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            class="moreButton"
            color="#3b87e0"
            plain
            @click="handleMore(scope.row)"
            >查看详情</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 作业审核对话框 -->
    <el-dialog :title="title" v-model="open" width="600px" append-to-body>
      <span class="Basic">| <span class="Mes">基本信息</span></span>
      <el-form
        ref="auditRef"
        :model="form"
        :rules="rules"
        label-width="80px"
        style="margin-top: 20px"
      >
        <el-form-item label="作业名称" prop="taskName">
          <el-input v-model="form.taskName" placeholder="请输入作业名称" />
        </el-form-item>
        <el-form-item label="是否通过" prop="approvalStatus">
          <el-radio-group v-model="form.approvalStatus">
            <el-radio
              v-for="dict in work_examine_status"
              :key="dict.value"
              :label="parseInt(dict.value)"
              >{{ dict.label }}</el-radio
            >
          </el-radio-group>
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input
            v-model="form.remark"
            type="textarea"
            placeholder="请输入审核意见"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">确 定</el-button>
          <el-button @click="cancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>

    <!-- 查看作业详情对话框 -->
    <el-dialog v-model="moreOpen" width="800px" append-to-body title="作业详情">
      <span class="Basic">| <span class="Mes">详细信息</span></span>
      <el-descriptions border column="2">
        <el-descriptions-item label="作业名称">{{
          moreform.taskName
        }}</el-descriptions-item>
        <el-descriptions-item label="作业类型">{{
          moreform.typeName
        }}</el-descriptions-item>
        <el-descriptions-item label="班组">{{
          moreform.deptName
        }}</el-descriptions-item>
        <el-descriptions-item label="风险名">{{
          moreform.riskName
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="作业位置">{{
          moreform.position
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="作业描述">{{
          moreform.taskDesc
        }}</el-descriptions-item>
        <el-descriptions-item label="作业时间">{{
          moreform.startTime
        }}</el-descriptions-item>
        <el-descriptions-item label="截止时间">{{
          moreform.endTime
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="负责人">{{
          moreform.mandateHolder
        }}</el-descriptions-item>
        <el-descriptions-item label="审核状态"
          ><el-tag size="small" :style="tagStyle" effect="dark">{{
            approvalStatusText
          }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="审核人">{{
          moreform.reviewer
        }}</el-descriptions-item>
        <el-descriptions-item label="创建人">{{
          moreform.createBy
        }}</el-descriptions-item>
        <el-descriptions-item label="创建时间">{{
          moreform.createTime
        }}</el-descriptions-item>
        <el-descriptions-item label="修改人">{{
          moreform.updateBy
        }}</el-descriptions-item>
        <el-descriptions-item label="修改时间">{{
          moreform.updateTime
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="备注">{{
          moreform.remark
        }}</el-descriptions-item>
      </el-descriptions>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="moreCancel">确 定</el-button>
          <el-button @click="moreCancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Audit">
import {
  listAudit,
  getAudit,
  addAudit,
  updateAudit,
  getRiskLibrary,
  getPoint,
} from "@/api/work/audit";

const { proxy } = getCurrentInstance();
const { work_examine_status } = proxy.useDict("work_examine_status");

const auditList = ref([]);
const riskId = ref([]);
const positionId = ref([]);

const open = ref(false);
const moreOpen = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const data = reactive({
  form: {},
  moreform: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    startTime: null,
    riskLevel: null,
    approvalStatus: null,
  },
  rules: {},
});

const { queryParams, form, moreform, rules } = toRefs(data);

/** 查询作业审批列表 */
async function getList() {
  loading.value = true;
  try {
    const response = await listAudit(queryParams.value);
    auditList.value = response.rows;
    riskId.value = response.rows.map((row) => row.riskId);
    positionId.value = response.rows.map((row) => row.positionId);

    // 逐一查询风险库
    await queryRiskNamesForIds(riskId.value);
    await queryPositionsForIds(positionId.value);

    total.value = response.total;
    loading.value = false;
  } catch (error) {
    console.error("获取任务列表失败:", error);
    loading.value = false;
  }
}
// 逐一查询风险库并更新 auditList
async function queryRiskNamesForIds(ids) {
  const promises = ids.map(async (id) => {
    const response = await getRiskLibrary(id);
    handleSingleRiskLibraryResponse(response.data, id);
  });

  await Promise.all(promises).catch((errors) =>
    console.error("部分请求失败:", errors)
  );
}
async function queryPositionsForIds(ids) {
  // 过滤掉 undefined、null 和无效值
  const validIds = ids.filter(id => id != null && id !== undefined && id !== '' && !isNaN(id));
  if (validIds.length === 0) {
    return;
  }
  const promises = validIds.map(async (id) => {
    const response = await getPoint(id);
    handleSingleGetPointResponse(response.data, id);
  });

  await Promise.all(promises).catch((errors) =>
    console.error("部分请求失败:", errors)
  );
}
// 处理单个风险库响应数据
function handleSingleRiskLibraryResponse(data, riskIdItem) {
  if (data && data.riskLevel) {
    const foundTask = auditList.value.find(
      (task) => task.riskId === riskIdItem
    );
    if (foundTask) {
      foundTask.riskLevel = data.riskLevel;
    }
  }
}
function handleSingleGetPointResponse(data, positionIdItem) {
  if (data && data.position) {
    auditList.value.forEach((task) => {
      if (task.positionId === positionIdItem) {
        task.position = data.position;
      }
    });
  }
}

// 取消按钮
function cancel() {
  open.value = false;
  reset();
}
function moreCancel() {
  moreOpen.value = false;
}
// 表单重置
function reset() {
  form.value = {
    id: null,
    taskName: null,
    typeName: null,
    deptName: null,
    startTime: null,
    endTime: null,
    riskName: null,
    mandateHolder: null,
    approvalStatus: null,
    reviewer: null,
    taskDesc: null,
    positionInfo: null,
    createBy: null,
    remark: null,
    createTime: null,
    updateBy: null,
    updateTime: null,
  };
  proxy.resetForm("auditRef");
}

/** 搜索按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// 多选框选中数据
function handleSelectionChange(selection) {
  ids.value = selection.map((item) => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 修改按钮操作 */
function handleUpdate(row) {
  reset();
  const _id = row.id || ids.value;
  getAudit(_id).then((response) => {
    form.value = response.data;
    open.value = true;
    title.value = "作业审批";
  });
}

/** 查看作业详情按钮操作 */
function handleMore(row) {
  const _id = row.id || ids.value;
  getAudit(_id).then((response) => {
    moreform.value = response.data;
    const riskId = response.data.riskId;
    const positionId = response.data.positionId;
    getRiskLibrary(riskId).then((response) => {
      moreform.value.riskName = response.data.riskName;
    });
    if (positionId != null && positionId !== undefined && !isNaN(positionId)) {
      getPoint(positionId).then((response) => {
        moreform.value.position = response.data.position;
      });
    }
    moreOpen.value = true;
  });
}

/** 提交按钮 */
function submitForm() {
  proxy.$refs["auditRef"].validate((valid) => {
    if (valid) {
      if (form.value.id != null) {
        updateAudit(form.value).then((response) => {
          proxy.$modal.msgSuccess("修改成功");
          open.value = false;
          getList();
        });
      } else {
        addAudit(form.value).then((response) => {
          proxy.$modal.msgSuccess("新增成功");
          open.value = false;
          getList();
        });
      }
    }
  });
}

/** 导出按钮操作 */
function handleExport() {
  proxy.download(
    "work/audit/export",
    {
      ...queryParams.value,
    },
    `audit_${new Date().getTime()}.xlsx`
  );
}

getList();
const getApprovalStatusStyles = (status) => {
  switch (status) {
    case 0:
      return {
        color: "#fb9a29",
        textShadow: "0px 0px 0.3px #fb9a29",
      };
    case 1:
      return {
        color: "#06c08b",
        textShadow: "0px 0px 0.3px #06c08b",
      };
    case 2:
      return {
        color: "#ff1a04",
        textShadow: "0px 0px 0.3px #ff1a04",
      };
    default:
      return {};
  }
};
const tagStyle = computed(() => {
  switch (moreform.value.approvalStatus) {
    case 0:
      return {
        backgroundColor: "#fb9a2922",
        color: "#fb9a29",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #fb9a29",
        fontSize: "13.5px",
      };
    case 1:
      return {
        backgroundColor: "#06c08b22",
        color: "#06c08b",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #06c08b",
        fontSize: "13.5px",
      };
    case 2:
      return {
        backgroundColor: "#ff1a0422",
        color: "#ff1a04",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #ff1a04",
        fontSize: "13.5px",
      };
    default:
      return {
        backgroundColor: "#ff1a0422",
        color: "#ff1a04",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #ff1a04",
        fontSize: "13.5px",
      };
  }
});

const approvalStatusText = computed(() => {
  switch (moreform.value.approvalStatus) {
    case 0:
      return "未审核";
    case 1:
      return "通过";
    case 2:
      return "未通过";
    default:
      return "未知状态";
  }
});
const risksLevel = ref([
  {
    value: "A",
    label: "风险最低",
  },
  {
    value: "B",
    label: "风险中等",
  },
  {
    value: "C",
    label: "C及C以上风险需要审核",
  },
  {
    value: "D",
    label: "风险最高",
  },
]);
</script>