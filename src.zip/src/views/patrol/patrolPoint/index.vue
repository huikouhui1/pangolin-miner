<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      ref="queryRef"
      :inline="true"
      v-show="showSearch"
      label-width="110px"
      ><el-row>
        <el-form-item label="巡查点名称" prop="patrolName">
          <el-input
            v-model="queryParams.patrolName"
            placeholder="请输入巡查点名称"
            clearable
            @keyup.enter="handleQuery"
          />
        </el-form-item>
        <el-form-item label="巡查点位置名" prop="position">
          <el-input
            v-model="queryParams.position"
            placeholder="请输入巡查点位置名"
            clearable
            @keyup.enter="handleQuery"
          />
        </el-form-item>
        <el-form-item label="安全员" prop="securityOfficer">
          <el-input
            v-model="queryParams.securityOfficer"
            placeholder="请输入安全员"
            clearable
            @keyup.enter="handleQuery"
          />
        </el-form-item>
        <el-col>
          <el-form-item label="状态" prop="status">
            <el-select
              v-model="queryParams.status"
              placeholder="请选择状态"
              clearable
              style="width: 215px"
            >
              <el-option
                v-for="dict in patrol_point_status"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              />
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button
              type="primary"
              icon="Search"
              @click="handleQuery"
              color="#03bd8a"
              style="text-shadow: 0 0 0.3px #fff"
              >查询</el-button
            >
            <el-button
              icon="Refresh"
              @click="resetQuery"
              style="text-shadow: 0 0 0.3px #606266"
              >重置</el-button
            >
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          color="#03bd8a"
          style="text-shadow: 0 0 0.3px #03bd8a"
          @click="handleAdd"
          v-hasPermi="['patrol:patrolPoint:add']"
          >新增</el-button
        >
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="Download"
          @click="handleExport"
          v-hasPermi="['patrol:patrolPoint:export']"
          >导出</el-button
        >
      </el-col>
      <right-toolbar
        v-model:showSearch="showSearch"
        @queryTable="getList"
      ></right-toolbar>
    </el-row>

    <el-table
      v-loading="loading"
      :data="patrolPointList"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="30" align="center" />
      <el-table-column label="序号" width="60" align="center" type="index"/>
      <el-table-column
        label="巡查点名称"
        width="200"
        align="center"
        prop="patrolName"
      />
      <el-table-column
        label="巡查点位置名"
        width="200"
        align="center"
        prop="position"
      />
      <el-table-column
        label="安全员"
        width="120"
        align="center"
        prop="securityOfficer"
      />
      <el-table-column
        label="最近巡查时间"
        width="120"
        align="center"
        prop="lastPatrolTime"
      >
        <template #default="scope">
          <span>{{ parseTime(scope.row.lastPatrolTime, "{y}-{m}-{d}") }}</span>
        </template>
      </el-table-column>
      <el-table-column label="状态" width="100" align="center" prop="status">
        <template #default="scope">
          <dict-tag
            :options="patrol_point_status"
            :value="scope.row.status"
            :style="getPointStatusStyles(scope.row.status)"
          />
        </template>
      </el-table-column>
      <el-table-column
        label="备注信息"
        width="250"
        align="center"
        prop="remark"
      />
      <el-table-column
        label="操作"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            class="editButton"
            color="#06c08b"
            plain
            @click="handleUpdate(scope.row)"
            v-hasPermi="['patrol:patrolPoint:edit']"
            >编辑</el-button
          >
          <el-button
            class="DelButton"
            color="#ff7b47"
            plain
            @click="handleDelete(scope.row)"
            v-hasPermi="['patrol:patrolPoint:remove']"
            >删除</el-button
          >
        </template>
      </el-table-column>
      <el-table-column
        label="巡查点详情"
        width="120"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            class="moreButton"
            color="#3b87e0"
            plain
            @click="handleMore(scope.row)"
            v-hasPermi="['patrol:patrolPoint:more']"
            >查看详情</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />
    <!-- 新增巡查点对话框 -->
    <el-dialog
      title="新增巡查点"
      v-model="addopen"
      width="650px"
      append-to-body
    >
      <span class="Basic">| <span class="Mes">基本信息</span></span>
      <el-form
        ref="patrolPointRef"
        :model="addform"
        :rules="rules"
        label-width="120px"
        style="padding-top: 20px; margin-left: -35px"
      >
        <el-form-item label="巡查点名称" prop="patrolName">
          <el-input
            v-model="addform.patrolName"
            placeholder="请输入巡查点名称"
          />
        </el-form-item>
        <el-form-item label="巡查点描述" prop="patrolDesc">
          <el-input
            v-model="addform.patrolDesc"
            placeholder="请输入巡查点描述"
          />
        </el-form-item>
        <el-form-item label="位置" prop="position">
          <el-input
            v-model="addform.position"
            placeholder="请输入巡查点位置名"
          />

          <el-button
            class="editButton"
            color="#06c08b"
            plain
            @click="openMapDialog"
            style="margin-top: 18px"
            >地图选点</el-button
          >
        </el-form-item>
        <el-dialog
          v-model="dialogVisible"
          title="请选择位置"
          width="80%"
          @close="closeMapDialog"
        >
          <div id="addcontainer" class="amap-box"></div>
          <template #footer>
            <span class="dialog-footer">
              <el-button @click="closeMapDialog">取消</el-button>
              <el-button type="primary" @click="confirmSelection"
                >确定</el-button
              >
            </span>
          </template>
        </el-dialog>
        <el-form-item label="具体位置" prop="locationDescribe">
          <el-input
            v-model="addform.locationDescribe"
            placeholder="请输入具体位置"
          />
        </el-form-item>
        <el-form-item label="安全员" prop="securityOfficer">
          <el-input
            v-model="addform.securityOfficer"
            placeholder="请输入安全员"
          />
        </el-form-item>
        <el-form-item label="状态" prop="status">
          <el-radio-group v-model="addform.status">
            <el-radio
              v-for="dict in patrol_point_status"
              :key="dict.value"
              :label="parseInt(dict.value)"
              >{{ dict.label }}</el-radio
            >
          </el-radio-group>
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input v-model="addform.remark" placeholder="请输入备注" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="addsubmitForm">确 定</el-button>
          <el-button @click="addcancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>

    <!-- 编辑巡查点对话框 -->
    <el-dialog
      title="编辑巡查点"
      v-model="editopen"
      width="650px"
      append-to-body
    >
      <span class="Basic">| <span class="Mes">基本信息</span></span>
      <el-form
        ref="patrolPointRef"
        :model="editform"
        :rules="rules"
        label-width="120px"
        style="padding-top: 20px; margin-left: -35px"
      >
        <el-form-item label="巡查点名称" prop="patrolName">
          <el-input
            v-model="editform.patrolName"
            placeholder="请输入巡查点名称"
          />
        </el-form-item>
        <el-form-item label="巡查点描述" prop="patrolDesc">
          <el-input
            v-model="editform.patrolDesc"
            placeholder="请输入巡查点描述"
          />
        </el-form-item>
        <el-form-item label="位置" prop="position">
          <el-input
            v-model="editform.position"
            placeholder="请输入巡查点位置"
          />
          <el-button
            class="editButton"
            color="#06c08b"
            plain
            @click="openMapDialog"
            style="margin-top: 18px"
            >地图选点</el-button
          >
        </el-form-item>
        <el-dialog
          v-model="dialogVisible"
          title="请选择位置"
          width="80%"
          @close="closeMapDialog"
        >
          <div id="addcontainer" class="amap-box"></div>
          <template #footer>
            <span class="dialog-footer">
              <el-button @click="closeMapDialog">取消</el-button>
              <el-button type="primary" @click="confirmSelectionEdit"
                >确定</el-button
              >
            </span>
          </template>
        </el-dialog>
        <el-form-item label="具体位置" prop="locationDescribe">
          <el-input
            v-model="editform.locationDescribe"
            placeholder="请描述具体位置"
          />
        </el-form-item>
        <el-form-item label="安全员" prop="securityOfficer">
          <el-input
            v-model="editform.securityOfficer"
            placeholder="请输入安全员"
          />
        </el-form-item>
        <el-form-item label="状态" prop="status">
          <el-radio-group v-model="editform.status">
            <el-radio
              v-for="dict in patrol_point_status"
              :key="dict.value"
              :label="parseInt(dict.value)"
              >{{ dict.label }}</el-radio
            >
          </el-radio-group>
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input v-model="editform.remark" placeholder="请输入备注" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="editsubmitForm">确 定</el-button>
          <el-button @click="editcancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
    <!-- 查看详情巡查点对话框 -->
    <el-dialog
      title="巡查点详情"
      v-model="moreopen"
      width="800px"
      append-to-body
    >
      <span class="Basic">| <span class="Mes">详细信息</span></span>
      <el-descriptions border column="2">
        <el-descriptions-item :span="2" label="巡查点名称">{{
          moreform.patrolName
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="巡查点描述">{{
          moreform.patrolDesc
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="位置">{{
          moreform.position
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="具体位置">{{
          moreform.locationDescribe
        }}</el-descriptions-item>
        <el-descriptions-item label="安全员">{{
          moreform.securityOfficer
        }}</el-descriptions-item>
        <el-descriptions-item label="状态"
          ><el-tag size="small" :style="tagStyle" effect="dark">{{
            pointStatusText
          }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item label="最近巡查时间">{{
          moreform.lastPatrolTime
        }}</el-descriptions-item>
        <el-descriptions-item label="巡查次数">{{
          moreform.patrolFrequency
        }}</el-descriptions-item>
        <el-descriptions-item label="创建人">{{
          moreform.createBy
        }}</el-descriptions-item>
        <el-descriptions-item label="创建时间">{{
          moreform.createTime
        }}</el-descriptions-item>
        <el-descriptions-item label="修改人">{{
          moreform.updateBy
        }}</el-descriptions-item>
        <el-descriptions-item label="修改时间">{{
          moreform.updateTime
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="备注">{{
          moreform.remark
        }}</el-descriptions-item>
      </el-descriptions>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="morecancel">确 定</el-button>
          <el-button @click="morecancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>
  
  <script setup name="PatrolPoint">
import {
  listPatrolPoint,
  getPatrolPoint,
  delPatrolPoint,
  addPatrolPoint,
  updatePatrolPoint,
} from "@/api/patrol/patrolPoint";
import { ElMessage } from "element-plus";

const dialogVisible = ref(false);
const selectedPoint = ref(null);
window._AMapSecurityConfig = {
  securityJsCode: "2be4ae83705eae86180548e3ce50890b",
};
function openMapDialog() {
  dialogVisible.value = true;
  // 动态加载高德地图 SDK
  const script = document.createElement("script");
  script.src =
    "https://webapi.amap.com/maps?v=2.0&key=714df26cdb5499337dd61b44fb59ea97&plugin=AMap.Map";
  script.onload = () => {
    // 确保高德地图 SDK 加载完成后才初始化地图
    initializeMap();
  };
  document.head.appendChild(script);
}
function closeMapDialog() {
  dialogVisible.value = false;
}
function confirmSelection() {
  if (selectedPoint.value) {
    addform.value.position = selectedPoint.value;
    dialogVisible.value = false;
    ElMessage.success("位置已选择");
  } else {
    ElMessage.error("请选择位置");
  }
}
function confirmSelectionEdit() {
  if (selectedPoint.value) {
    editform.value.position = selectedPoint.value;
    dialogVisible.value = false;
    ElMessage.success("位置已选择");
  } else {
    ElMessage.error("请选择位置");
  }
}
function initializeMap() {
  // 初始化地图实例
  const map = new AMap.Map("addcontainer", {
    zoom: 15,
    layers: [new AMap.TileLayer.Satellite()],
    center: [122.958593, 41.066896],
  });
  var infoWindow = new AMap.InfoWindow({
    offset: new AMap.Pixel(0, -30),
  });
  // 调用高德地图的逆地理编码服务
  AMap.plugin("AMap.Geocoder", function () {
    var geocoder = new AMap.Geocoder({
      city: "0371", // 城市，可选，默认是全国
      radius: 1000, // 范围，默认是500
    });
    // 监听点击事件
    map.on("click", function (e) {
      let lnglat = e.lnglat; // 获取点击位置的经纬度坐标
      console.log(lnglat.lng, lnglat.lat); // 显示经纬度坐标
      geocoder.getAddress(lnglat, function (status, result) {
        if (status === "complete" && result.regeocode) {
          var address = result.regeocode.formattedAddress; // 获取解析后的结果，即位置信息的地名
          selectedPoint.value = address;
          console.log(address); // 显示位置信息的地名
          infoWindow.setContent(address);
          infoWindow.open(map, lnglat);
        }
      });
    });
  });
}

const { proxy } = getCurrentInstance();
const { patrol_point_status } = proxy.useDict("patrol_point_status");

const patrolPointList = ref([]);

const addopen = ref(false);
const editopen = ref(false);
const moreopen = ref(false);

const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const data = reactive({
  addform: {},
  editform: {},
  moreform: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    patrolName: null,
    position: null,
    securityOfficer: null,
    status: null,
  },
  rules: {
    patrolName: [
      { required: true, message: "巡查点名称不能为空", trigger: "blur" },
    ],
    patrolDesc: [
      { required: true, message: "巡查点描述不能为空", trigger: "blur" },
    ],
    position: [
      { required: true, message: "巡查点位置名不能为空", trigger: "blur" },
    ],
  },
});

const { queryParams, addform, editform, moreform, rules } = toRefs(data);

/** 查询巡查点管理列表 */
function getList() {
  loading.value = true;
  listPatrolPoint(queryParams.value).then((response) => {
    patrolPointList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}

// 取消按钮
function addcancel() {
  addopen.value = false;
  reset();
}
function editcancel() {
  editopen.value = false;
  reset();
}
function morecancel() {
  moreopen.value = false;
}

// 表单重置
function reset() {
  addform.value = {
    id: null,
    patrolName: null,
    patrolDesc: null,
    position: null,
    locationDescribe: null,
    securityOfficer: null,
    lastPatrolTime: null,
    patrolFrequency: null,
    status: null,
    delFlag: null,
    createBy: null,
    createTime: null,
    updateBy: null,
    updateTime: null,
    remark: null,
  };
  editform.value = {
    id: null,
    patrolName: null,
    patrolDesc: null,
    position: null,
    locationDescribe: null,
    securityOfficer: null,
    lastPatrolTime: null,
    patrolFrequency: null,
    status: null,
    delFlag: null,
    createBy: null,
    createTime: null,
    updateBy: null,
    updateTime: null,
    remark: null,
  };
  proxy.resetForm("patrolPointRef");
}

/** 查询按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// 多选框选中数据
function handleSelectionChange(selection) {
  ids.value = selection.map((item) => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 新增按钮操作 */
function handleAdd() {
  reset();
  addopen.value = true;
}

/** 编辑按钮操作 */
function handleUpdate(row) {
  reset();
  const _id = row.id || ids.value;
  getPatrolPoint(_id).then((response) => {
    editform.value = response.data;
    editopen.value = true;
  });
}
function handleMore(row) {
  const _id = row.id || ids.value;
  getPatrolPoint(_id).then((response) => {
    moreform.value = response.data;
    moreopen.value = true;
  });
}
/** 提交按钮 */
function addsubmitForm() {
  addPatrolPoint(addform.value).then((response) => {
    proxy.$modal.msgSuccess("新增成功");
    addopen.value = false;
    getList();
  });
}
function editsubmitForm() {
  updatePatrolPoint(editform.value).then((response) => {
    proxy.$modal.msgSuccess("编辑成功");
    editopen.value = false;
    getList();
  });
}

/** 删除按钮操作 */
function handleDelete(row) {
  const _ids = row.id || ids.value;
  proxy.$modal
    .confirm('是否确认删除巡查点编号为"' + _ids + '"的数据项？')
    .then(function () {
      return delPatrolPoint(_ids);
    })
    .then(() => {
      getList();
      proxy.$modal.msgSuccess("删除成功");
    })
    .catch(() => {});
}

/** 导出按钮操作 */
function handleExport() {
  proxy.download(
    "patrol/patrolPoint/export",
    {
      ...queryParams.value,
    },
    `patrolPoint_${new Date().getTime()}.xlsx`
  );
}

getList();

const getPointStatusStyles = (status) => {
  switch (status) {
    case 0:
      return {
        color: "#06c08b",
        textShadow: "0px 0px 0.3px #06c08b",
      };
    case 1:
      return {
        color: "#ff1a04",
        textShadow: "0px 0px 0.3px #ff1a04",
      };
    default:
      return {};
  }
};
const tagStyle = computed(() => {
  switch (moreform.value.status) {
    case 0:
      return {
        backgroundColor: "#06c08b22",
        color: "#06c08b",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #06c08b",
        fontSize: "13.5px",
      };
    case 1:
      return {
        backgroundColor: "#ff1a0422",
        color: "#ff1a04",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #ff1a04",
        fontSize: "13.5px",
      };
    default:
      return {
        backgroundColor: "#ff1a0422",
        color: "#ff1a04",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #ff1a04",
        fontSize: "13.5px",
      };
  }
});
const pointStatusText = computed(() => {
  switch (moreform.value.status) {
    case 0:
      return "正常";
    case 1:
      return "停用";
    default:
      return "未知状态";
  }
});
</script>
<style lang="scss" scoped>
.amap-box {
  width: 100%;
  height: 100%; // 设置地图的高度为容器的高度
  min-height: 500px; // 设置最小高度
}
</style>
  