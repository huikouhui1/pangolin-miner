<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      ref="queryRef"
      :inline="true"
      v-show="showSearch"
      label-width="100px"
    >
      <el-form-item label="待查项名称" prop="unverifiedRiskName">
        <el-select
          style="width: 220px"
          v-model="queryParams.unverifiedRiskName"
          placeholder="请选择待查项名称"
          clearable
          @keyup.enter="handleQuery"
        >
          <el-option
            v-for="item in AllunverifiedRiskNames"
            :key="item.unverifiedRiskName"
            :label="item.unverifiedRiskName"
            :value="item.unverifiedRiskName"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="巡查位置" prop="position">
        <el-select
          style="width: 220px"
          v-model="queryParams.position"
          placeholder="请选择巡查位置"
          clearable
          @keyup.enter="handleQuery"
        >
          <el-option
            v-for="item in Allpositions"
            :key="item.positionId"
            :label="item.position"
            :value="item.positionId"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          icon="Search"
          @click="handleQuery"
          color="#03bd8a"
          style="text-shadow: 0 0 0.3px #fff"
          >查询</el-button
        >
        <el-button
          icon="Refresh"
          @click="resetQuery"
          style="text-shadow: 0 0 0.3px #606266"
          >重置</el-button
        >
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <right-toolbar
        v-model:showSearch="showSearch"
        @queryTable="getList"
      ></right-toolbar>
    </el-row>

    <el-table
      v-loading="loading"
      :data="riskPendList"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="30" align="center" />
      <el-table-column label="序号" width="60" align="center" type="index"/>
      <el-table-column
        label="待查项名称"
        width="200"
        align="center"
        prop="unverifiedRiskName"
      />
      <el-table-column
        label="巡查位置"
        width="150"
        align="center"
        prop="position"
      />
      <el-table-column
        label="巡查标准"
        width="180"
        align="center"
        prop="controlStandard"
      />
      <el-table-column label="安全员" width="120" align="center" prop="admin" />
      <el-table-column
        label="巡查日期"
        width="120"
        align="center"
        prop="updateTime"
      />
      <el-table-column label="备注" width="250" align="center" prop="remark" />
      <el-table-column
        label="点击查看"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            class="editButton"
            color="#06c08b"
            plain
            @click="handleRisk(scope.row)"
            v-hasPermi="['risk:riskPend:edit']"
            >风险</el-button
          >
          <el-button
            class="moreButton"
            color="#3b87e0"
            plain
            @click="handlePatrolRecord(scope.row)"
            v-hasPermi="['risk:riskPend:edit']"
            >巡查记录
          </el-button>
          <el-button
            class="DelButton"
            color="#ff7b47"
            plain
            @click="handleDelete(scope.row)"
            v-hasPermi="['risk:riskPend:remove']"
            >删除</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 风险对话框 -->
    <el-dialog title="风险详情" v-model="riskopen" width="800px" append-to-body>
      <span class="Basic">| <span class="Mes">详细信息</span></span>
      <el-descriptions border column="2">
        <el-descriptions-item label="风险名">{{
          riskform.riskName
        }}</el-descriptions-item>
        <el-descriptions-item label="审核人">{{
          riskform.auditor
        }}</el-descriptions-item>
        <el-descriptions-item label="风险类型">{{
          riskform.riskType
        }}</el-descriptions-item>
        <el-descriptions-item label="风险等级">{{
          riskform.riskLevel
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="风险信息">{{
          riskform.riskInfo
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="风险描述">{{
          riskform.riskDescribe
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="风险后果">{{
          riskform.riskConseq
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="管理措施">{{
          riskform.controlMeasure
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="备注">{{
          riskform.remark
        }}</el-descriptions-item>
      </el-descriptions>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="morecancel">确 定</el-button>
          <el-button @click="morecancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
    <!-- 巡查记录对话框 -->
    <el-dialog
      title="巡查记录"
      v-model="patrolrecordopen"
      width="650px"
      append-to-body
    >
      <span class="Basic">| <span class="Mes">详细信息</span></span>
      <el-descriptions border column="1">
        <el-descriptions-item label="巡查状态"
          ><el-tag :style="tagStyle" effect="dark">{{
            patrolStatusDescription
          }}</el-tag></el-descriptions-item
        >
        <el-descriptions-item label="提交时间">{{
          patrolrecordform.updateTime
        }}</el-descriptions-item>
        <el-descriptions-item label="备注">{{
          patrolrecordform.remark
        }}</el-descriptions-item>
      </el-descriptions>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="morecancel">确 定</el-button>
          <el-button @click="morecancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>
  
  <script setup name="patrolRecordList">
import {
  listRiskPend,
  listRiskPendAll,
  listPatrolPointAll,
  getRiskPend,
  getRiskLibrary,
  delRiskPend,
  getPoint,
} from "@/api/risk/riskPend";

const { proxy } = getCurrentInstance();

const riskPendList = ref([]);
const positionId = ref([]);
const positions = ref([]);
const unverifiedRiskNames = ref([]);
const AllunverifiedRiskNames = ref([]);
const Allpositions = ref([]);

const riskopen = ref(false);
const patrolrecordopen = ref(false);

const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);

const route = useRoute();
const data = reactive({
  riskform: {},
  patrolrecordform: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    unverifiedRiskName: null,
    position: null,
    patrolListId: null,
  },
});

const { queryParams, riskform, patrolrecordform } = toRefs(data);

const patrolStatusDescription = computed(() => {
  switch (patrolrecordform.value.status) {
    case 0:
      return "未处理";
    case 1:
      return "未发现隐患";
    case 2:
      return "发现隐患";
    default:
      return "未知状态";
  }
});
const tagStyle = computed(() => {
  switch (patrolrecordform.value.status) {
    case 0:
      return {
        backgroundColor: "#fb9a2922",
        color: "#fb9a29",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #fb9a29",
        fontSize: "13.5px",
      };
    case 1:
      return {
        backgroundColor: "#06c08b22",
        color: "#06c08b",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #06c08b",
        fontSize: "13.5px",
      };
    case 2:
      return {
        backgroundColor: "#ff1a0422",
        color: "#ff1a04",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #ff1a04",
        fontSize: "13.5px",
      };
    default:
      return {
        backgroundColor: "#ff1a0422",
        color: "#ff1a04",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #ff1a04",
        fontSize: "13.5px",
      };
  }
});
/** 查询风险项管理列表 */
async function getList() {
  loading.value = true;
  // 处理路由参数，如果不存在或无效则设为 null
  const id = route.params.id ? parseInt(route.params.id) : null;
  data.queryParams.patrolListId = (id && !isNaN(id)) ? id : null;
  try {
    const response = await listRiskPend(queryParams.value);
    riskPendList.value = response.rows;
    total.value = response.total;
    response.rows.forEach((item) => {
      item.updateTime = item.updateTime.split(" ")[0];
    });

    // position 是位置名称字符串，不是 ID，直接使用去重后的位置名称
    const uniquePositions = [...new Set(response.rows.map((row) => row.position).filter(p => p))];
    positions.value = uniquePositions.map((position, index) => ({
      positionId: index + 1,
      position: position
    }));

    loading.value = false;
  } catch (error) {
    console.error("获取任务列表失败:", error);
    loading.value = false;
  }
}
async function getListAll() {
  loading.value = true;
  try {
    const response1 = await listRiskPendAll();
    AllunverifiedRiskNames.value = response1.rows.map(
      (unverifiedRiskName, unverifiedRiskid) => {
        return {
          unverifiedRiskid: unverifiedRiskid + 1,
          unverifiedRiskName: unverifiedRiskName.unverifiedRiskName,
        };
      }
    );
    console.log(AllunverifiedRiskNames.value);
    const response2 = await listPatrolPointAll();
    Allpositions.value = response2.rows.map((position, positionId) => {
      return {
        position: position.position,
        positionId: positionId + 1,
      };
    });
    console.log(Allpositions.value);
  } catch (error) {
    console.error("获取列表失败:", error);
    loading.value = false;
  }
}
async function queryPositionsForIds(ids) {
  // 过滤掉 undefined、null 和无效值
  const validIds = ids.filter(id => id != null && id !== undefined && id !== '');
  if (validIds.length === 0) {
    return;
  }
  const promises = validIds.map(async (id) => {
    const response = await getPoint(id);
    handleSingleGetPointResponse(response.data, id);
  });
  await Promise.all(promises).catch((errors) =>
    console.error("部分请求失败:", errors)
  );
}
function handleSingleGetPointResponse(data, positionIdItem) {
  if (data && data.position) {
    const existingRiskIndex = positions.value.findIndex(
      (item) => item.positionId === positionIdItem
    );
    if (existingRiskIndex === -1) {
      positions.value.push({
        positionId: positionIdItem,
        position: data.position,
      });
    } else {
      positions.value[existingRiskIndex].position = data.position;
    }

    const foundTask = riskPendList.value.find(
      (task) => task.position === positionIdItem
    );
    if (foundTask) {
      foundTask.position = data.position;
    }
  }
}

// 取消按钮
function morecancel() {
  riskopen.value = false;
  patrolrecordopen.value = false;
}

/** 搜索按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
  getListAll();
}

/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// 多选框选中数据
function handleSelectionChange(selection) {
  ids.value = selection.map((item) => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 风险按钮操作 */
function handleRisk(row) {
  const _id = row.id || ids.value;
  getRiskPend(_id).then((response) => {
    const getRiskId = response.data.riskId;
    getRiskLibrary(getRiskId).then((response) => {
      riskform.value = response.data;
      riskopen.value = true;
    });
  });
}

/** 巡查记录按钮操作 */
function handlePatrolRecord(row) {
  const _id = row.id || ids.value;
  getRiskPend(_id).then((response) => {
    patrolrecordform.value = response.data;
    patrolrecordopen.value = true;
  });
}

/** 删除按钮操作 */
function handleDelete(row) {
  const _ids = row.id || ids.value;
  proxy.$modal
    .confirm('是否确认删除风险项编号为"' + _ids + '"的数据项？')
    .then(function () {
      return delRiskPend(_ids);
    })
    .then(() => {
      getList();
      getListAll();
      proxy.$modal.msgSuccess("删除成功");
    })
    .catch(() => {});
}

getList();
getListAll();
</script>
  