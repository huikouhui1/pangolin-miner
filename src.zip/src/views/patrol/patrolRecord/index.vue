<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      ref="queryRef"
      :inline="true"
      v-show="showSearch"
      label-width="110px"
    >
      <el-form-item label="巡查清单名称" prop="patrolListName">
        <el-input
          v-model="queryParams.patrolListName"
          placeholder="请输入巡查清单名称"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="巡查日期" prop="startTime">
        <el-date-picker
          clearable
          v-model="queryParams.startTime"
          type="date"
          value-format="YYYY-MM-DD"
          placeholder="请选择巡查日期"
        >
        </el-date-picker>
      </el-form-item>
      <el-form-item label="清单状态" prop="status">
        <el-radio-group v-model="queryParams.status">
          <el-radio
            v-for="dict in patrol_list_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
            >{{ dict.label }}</el-radio
          >
        </el-radio-group>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          icon="Search"
          color="#03bd8a"
          @click="handleQuery"
          style="text-shadow: 0 0 0.3px #fff"
          >查询</el-button
        >
        <el-button
          icon="Refresh"
          @click="resetQuery"
          style="text-shadow: 0 0 0.3px #606266"
          >重置</el-button
        >
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <right-toolbar
        v-model:showSearch="showSearch"
        @queryTable="getList"
      ></right-toolbar>
    </el-row>
    <div style="display: flex; flex-wrap: wrap">
      <div
        class="cardflex"
        style="width: 380px; margin-right: 50px; margin-bottom: 35px"
        v-for="item in patrolList"
        :key="item.id"
      >
        <!-- v-loading="loading" -->
        <div class="top">
          <span class="patrolListName">{{ item.patrolListName }}</span>
          <div style="display: flex; align-items: center">
            <img
              :src="getStatusImg(item.status)"
              alt=""
              style="
                width: 17px;
                height: 18px;
                margin-right: 5px;
                padding-bottom: 1px;
              "
            /><span class="status" :style="getStatusStyle(item.status)">{{
              getStatusText(item.status)
            }}</span>
          </div>
        </div>
        <div class="middle">
          <div class="middle-box">
            <span class="text">已巡查：{{ item.checkedCount }}项</span>
            <span class="text">安全员：{{ item.nickName }}</span>
          </div>
          <div class="middle-box">
            <span class="text" style="color: red; text-shadow: 0 0 0.2px red"
              >异常项：{{ item.hiddenTroubleCount }}项</span
            >
            <span class="text"
              >巡查进度：{{
                Math.floor((item.checkedCount / item.waitingChecked) * 100)
              }}%</span
            >
          </div>
        </div>
        <div class="bottom">
          <el-button
            class="editButton"
            color="#06c08b"
            plain
            @click="handleLook(item.id)"
            v-hasPermi="['patrol:patrolRecord:look']"
            >查看</el-button
          >
          <el-button
            class="DelButton"
            color="#ff7b47"
            plain
            @click="handleDelete(item.id)"
            v-hasPermi="['patrol:patrolRecord:remove']"
            >删除</el-button
          >
        </div>
      </div>
    </div>
    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />
  </div>
</template>

<script setup name="patrolRecord">
import {
  listpatrolRecord,
  delpatrolRecord,
  getUser,
} from "@/api/patrol/patrolRecord";

import router from "@/router";
import redDot from "../../../assets/images/patrol/小圆点_红.png";
import greenDot from "../../../assets/images/patrol/小圆点_绿.png";
import blueDot from "../../../assets/images/patrol/小圆点_蓝.png";
const { proxy } = getCurrentInstance();
const { patrol_list_status } = proxy.useDict("patrol_list_status");

const patrolList = ref([]);
const loading = ref(true);
const showSearch = ref(true);
const total = ref(0);

const data = reactive({
  queryParams: {
    pageNum: 1,
    pageSize: 9,
    patrolListName: null,
    startTime: null,
    status: null,
  },
});
const { queryParams } = toRefs(data);
/** 查询作业审批列表 */
async function getList() {
  loading.value = true;
  try {
    const response = await listpatrolRecord(queryParams.value);
    const userPromises = response.rows.map(async (item) => {
      const userResponse = await getUser(item.principalId);
      item.nickName = userResponse.data.nickName;
    });
    await Promise.all(userPromises);
    patrolList.value = response.rows;
    total.value = response.total;
  } catch (error) {
    console.error("An error occurred:", error);
  } finally {
    loading.value = false;
  }
}

/** 搜索按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// 查看按钮操作
function handleLook(id) {
  router.push({
    path: "/patrol/patrolRecord-look/index/" + id,
    query: { pageNum: queryParams.value.pageNum },
  });
}

/** 删除按钮操作 */
function handleDelete(_ids) {
  proxy.$modal
    .confirm('是否确认删除巡查清单编号为"' + _ids + '"的数据项？')
    .then(function () {
      return delpatrolRecord(_ids);
    })
    .then(() => {
      getList();
      proxy.$modal.msgSuccess("删除成功");
    })
    .catch(() => {});
}

getList();
const getStatusText = (status) => {
  return status === 0 ? "未开始" : status === 1 ? "巡查中" : "已结束";
};
const getStatusStyle = (status) => {
  switch (status) {
    case 0:
      return {
        color: "#ef3a29",
        textShadow: "0px 0px 0.3px #ef3a29",
        fontSize: "15px",
      };
    case 1:
      return {
        color: "#06c08b",
        textShadow: "0px 0px 0.3px #06c08b",
        fontSize: "15px",
      };
    case 2:
      return {
        color: "#3b87e0",
        textShadow: "0px 0px 0.3px #3b87e0",
        fontSize: "15px",
      };
    default:
      return {};
  }
};
const getStatusImg = (status) => {
  switch (status) {
    case 0:
      return redDot;
    case 1:
      return greenDot;
    case 2:
      return blueDot;
    default:
      return "";
  }
};
</script>
  <style lang="scss" scoped>
.cardflex {
  display: flex;
  flex-direction: column;
  padding: 12px 0px 8px;
  background-color: #f9fbfd;
  box-shadow: 0 0 2px #c2c3c4;
  border-radius: 5px;
  .top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 16px 8px;
    border-bottom: 1px solid #d8d9da;
    .patrolListName {
      color: #2f3e50;
      font-size: 14.8px;
      letter-spacing: 1px;
      text-shadow: 0 0 0.3px #2f3e50;
    }
  }
  .middle {
    display: flex;
    justify-content: space-between;
    padding: 0px 20px 5px;
    margin-right: 60px;
    .middle-box {
      display: flex;
      flex-direction: column;
      .text {
        font-size: 14.2px;
        color: #414e60;
        padding-top: 12px;
      }
    }
  }
  .bottom {
    display: flex;
    justify-content: flex-end;
    padding: 5px 16px 0;
  }
}
</style>