<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      ref="queryRef"
      :inline="true"
      v-show="showSearch"
      label-width="80px"
    >
      <el-form-item label="风险名称" prop="riskName">
        <el-input
          v-model="queryParams.riskName"
          placeholder="请输入风险名称"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="监管人员" prop="supervisor">
        <el-input
          v-model="queryParams.supervisor"
          placeholder="请输入监管人员"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="审核人" prop="auditor">
        <el-input
          v-model="queryParams.auditor"
          placeholder="请输入审核人"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="风险级别" prop="riskLevel">
        <el-select
          clearable
          style="width: 245px"
          v-model="queryParams.riskLevel"
          placeholder="请选择风险级别"
        >
          <el-option
            v-for="item in risksLevel"
            :key="item.value"
            :label="item.value"
            :value="item.value"
          >
            <span
              style="
                float: right;
                color: var(--el-text-color-secondary);
                font-size: 15px;
              "
              >{{ item.label }}</span
            >
            <span style="float: left">
              {{ item.value }}
            </span>
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="风险类型" prop="riskType">
        <el-radio-group v-model="queryParams.riskType">
          <el-radio
            v-for="dict in risksType"
            :key="dict.value"
            :label="dict.value"
            :value="dict.value"
            >{{ dict.label }}</el-radio
          >
        </el-radio-group>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          icon="Search"
          @click="handleQuery"
          color="#03bd8a"
          style="text-shadow: 0 0 0.3px #fff"
          >查询</el-button
        >
        <el-button
          icon="Refresh"
          @click="resetQuery"
          style="text-shadow: 0 0 0.3px #606266"
          >重置</el-button
        >
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          color="#03bd8a"
          style="text-shadow: 0 0 0.3px #03bd8a"
          @click="handleAdd"
          v-hasPermi="['risk:riskLibrary:add']"
          >新增</el-button
        >
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="Download"
          @click="handleExport"
          v-hasPermi="['risk:riskLibrary:export']"
          >导出</el-button
        >
      </el-col>
      <right-toolbar
        v-model:showSearch="showSearch"
        @queryTable="getList"
      ></right-toolbar>
    </el-row>

    <el-table
      v-loading="loading"
      :data="riskLibraryList"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="30" align="center" />
      <el-table-column label="序号" width="60" align="center" type="index"/>
      <el-table-column
        label="风险名称"
        width="200"
        align="center"
        prop="riskName"
      />
      <el-table-column
        label="风险类型"
        width="160"
        align="center"
        prop="riskType"
      />
      <el-table-column
        label="风险等级"
        width="110"
        align="center"
        prop="riskLevel"
      />
      <el-table-column
        label="监管人员"
        width="160"
        align="center"
        prop="supervisor"
      />
      <el-table-column
        label="风险描述"
        width="380"
        align="center"
        prop="riskDescribe"
      />
      <el-table-column
        label="操作"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            class="editButton"
            color="#06c08b"
            plain
            @click="handleUpdate(scope.row)"
            v-hasPermi="['risk:riskLibrary:edit']"
            >编辑</el-button
          >
          <el-button
            class="DelButton"
            color="#ff7b47"
            plain
            @click="handleDelete(scope.row)"
            v-hasPermi="['risk:riskLibrary:remove']"
            >删除</el-button
          >
        </template>
      </el-table-column>
      <el-table-column
        label="风险详情"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            class="moreButton"
            color="#3b87e0"
            plain
            @click="handleMore(scope.row)"
            >查看详情</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 新增风险库管理对话框 -->
    <el-dialog :title="title" v-model="addopen" width="650px" append-to-body>
      <span class="Basic">| <span class="Mes">基本信息</span></span>
      <el-form
        ref="riskLibraryRef"
        :model="addform"
        :rules="rules"
        label-width="120px"
        style="padding-top: 20px; margin-left: -35px"
      >
        <el-form-item label="风险名称" prop="riskName">
          <el-input v-model="addform.riskName" placeholder="请输入风险名称" />
        </el-form-item>
        <el-form-item label="风险类型" prop="riskType">
          <el-select
            v-model="addform.riskType"
            placeholder="请选择风险类型"
            style="width: 240px"
          >
            <el-option
              v-for="item in risksType"
              :key="item.value"
              :label="item.value"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="风险等级" prop="riskLevel">
          <el-select
            v-model="addform.riskLevel"
            placeholder="请选择风险等级"
            style="width: 240px"
          >
            <el-option
              v-for="item in risksLevel"
              :key="item.value"
              :label="item.value"
              :value="item.value"
            >
              <span
                style="
                  float: right;
                  color: var(--el-text-color-secondary);
                  font-size: 15px;
                "
                >{{ item.label }}</span
              >
              <span style="float: left">
                {{ item.value }}
              </span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="审核人" prop="auditor">
          <el-input v-model="addform.auditor" placeholder="请输入审核人" />
        </el-form-item>
        <el-form-item label="风险信息" prop="riskInfo">
          <el-input v-model="addform.riskInfo" placeholder="请输入风险信息" />
        </el-form-item>
        <el-form-item label="风险描述" prop="riskDescribe">
          <el-input
            v-model="addform.riskDescribe"
            type="textarea"
            placeholder="请输入风险描述内容"
          />
        </el-form-item>
        <el-form-item label="风险后果" prop="riskConseq">
          <el-input
            v-model="addform.riskConseq"
            type="textarea"
            placeholder="请输入风险后果内容"
          />
        </el-form-item>
        <el-form-item label="风险管理措施" prop="controlMeasure">
          <el-input
            v-model="addform.controlMeasure"
            type="textarea"
            placeholder="请输入风险管理措施内容"
          />
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input
            v-model="addform.remark"
            type="textarea"
            placeholder="请输入备注内容"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="addsubmitForm">确 定</el-button>
          <el-button @click="addcancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
    <!-- 编辑 -->
    <el-dialog :title="title" v-model="editopen" width="650px" append-to-body>
      <span class="Basic">| <span class="Mes">基本信息</span></span>
      <el-form
        ref="riskLibraryRef"
        :model="editform"
        :rules="rules"
        label-width="120px"
        style="padding-top: 20px; margin-left: -35px"
      >
        <el-form-item label="风险名称" prop="riskName">
          <el-input
            v-model="editform.riskName"
            placeholder="请输入风险名称"
          /> </el-form-item
        ><el-form-item label="风险类型" prop="riskType">
          <el-select
            v-model="editform.riskType"
            placeholder="请选择风险类型"
            style="width: 240px"
          >
            <el-option
              v-for="item in risksType"
              :key="item.value"
              :label="item.value"
              :value="item.value"
            />
          </el-select> </el-form-item
        ><el-form-item label="风险等级" prop="riskLevel">
          <el-select
            v-model="editform.riskLevel"
            style="width: 240px"
            placeholder="请选择风险等级"
          >
            <el-option
              v-for="item in risksLevel"
              :key="item.value"
              :label="item.value"
              :value="item.value"
            >
              <span
                style="
                  float: right;
                  color: var(--el-text-color-secondary);
                  font-size: 13px;
                "
                >{{ item.label }}</span
              >
              <span style="float: left">
                {{ item.value }}
              </span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="风险信息" prop="riskInfo">
          <el-input
            v-model="editform.riskInfo"
            placeholder="请输入风险信息，如作为设备风险则说明是什么设备，作为生产现场风险说明哪些生产现场，作为风险活动说明哪个风险"
          />
        </el-form-item>
        <el-form-item label="风险描述" prop="riskDescribe">
          <el-input
            v-model="editform.riskDescribe"
            type="textarea"
            placeholder="请输入风险描述内容"
          />
        </el-form-item>
        <el-form-item label="风险后果" prop="riskConseq">
          <el-input
            v-model="editform.riskConseq"
            type="textarea"
            placeholder="请输入风险后果内容"
          />
        </el-form-item>
        <el-form-item label="风险管理措施" prop="controlMeasure">
          <el-input
            v-model="editform.controlMeasure"
            type="textarea"
            placeholder="请输入风险管理措施内容"
          />
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input
            v-model="editform.remark"
            type="textarea"
            placeholder="请输入备注内容"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="editsubmitForm">确 定</el-button>
          <el-button @click="editcancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
    <!-- 查看详情 -->
    <el-dialog v-model="moreopen" width="800px" append-to-body title="风险详情">
      <span class="Basic">| <span class="Mes">详细信息</span></span>
      <el-descriptions border column="2">
        <el-descriptions-item :span="2" label="风险名称">{{
          moreform.riskName
        }}</el-descriptions-item>
        <el-descriptions-item label="风险类型">{{
          moreform.riskType
        }}</el-descriptions-item>
        <el-descriptions-item label="风险等级">{{
          moreform.riskLevel
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="风险信息">{{
          moreform.riskInfo
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="风险描述">{{
          moreform.riskDescribe
        }}</el-descriptions-item>
        <el-descriptions-item label="审核人">{{
          moreform.auditor
        }}</el-descriptions-item>
        <el-descriptions-item label="监管人员">{{
          moreform.supervisor
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="管控标准">{{
          moreform.controlStandard
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="风险后果">{{
          moreform.riskConseq
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="管理措施">{{
          moreform.controlMeasure
        }}</el-descriptions-item>
        <el-descriptions-item label="创建人">{{
          moreform.createBy
        }}</el-descriptions-item>
        <el-descriptions-item label="创建时间">{{
          moreform.createTime
        }}</el-descriptions-item>
        <el-descriptions-item label="修改人">{{
          moreform.updateBy
        }}</el-descriptions-item>
        <el-descriptions-item label="修改时间">{{
          moreform.updateTime
        }}</el-descriptions-item>
        <el-descriptions-item label="备注">{{
          moreform.remark
        }}</el-descriptions-item>
      </el-descriptions>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="morecancel">确 定</el-button>
          <el-button @click="morecancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>
  
  <script setup name="RiskLibrary">
import {
  listRiskLibrary,
  getRiskLibrary,
  delRiskLibrary,
  addRiskLibrary,
  updateRiskLibrary,
} from "@/api/risk/riskLibrary";

const { proxy } = getCurrentInstance();

const riskLibraryList = ref([]);
const addopen = ref(false);
const editopen = ref(false);
const moreopen = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");
const data = reactive({
  addform: {},
  editform: {},
  moreform: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    riskName: null,
    riskType: null,
    supervisor: null,
    riskLevel: null,
    auditor: null,
  },
  rules: {
    riskName: [
      { required: true, message: "风险名称不能为空", trigger: "blur" },
    ],
    riskType: [
      { required: true, message: "风险类型不能为空", trigger: "change" },
    ],
    riskLevel: [
      { required: true, message: "风险等级不能为空", trigger: "change" },
    ],
    riskConseq: [
      { required: true, message: "风险后果不能为空", trigger: "blur" },
    ],
    controlMeasure: [
      { required: true, message: "风险管理措施不能为空", trigger: "blur" },
    ],
  },
});

const { queryParams, addform, editform, moreform, rules } = toRefs(data);
const risksLevel = ref([
  {
    value: "A",
    label: "风险最高",
  },
  {
    value: "B",
    label: "B及B以上风险需要审核",
  },
  {
    value: "C",
    label: "风险中等",
  },
  {
    value: "D",
    label: "风险最低",
  },
]);
const risksType = ref([
  {
    value: "作业风险",
    label: "作业风险",
  },
  {
    value: "生产现场风险",
    label: "生产现场风险",
  },
  {
    value: "设备风险",
    label: "设备风险",
  },
  {
    value: "其他",
    label: "其他",
  },
]);
/** 查询风险库管理列表 */
function getList() {
  loading.value = true;
  listRiskLibrary(queryParams.value).then((response) => {
    riskLibraryList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}

// 取消按钮
function addcancel() {
  addopen.value = false;
  addreset();
}
function editcancel() {
  editopen.value = false;
  editreset();
}
function morecancel() {
  moreopen.value = false;
}

// 表单重置
function addreset() {
  addform.value = {
    id: null,
    riskName: null,
    riskType: null,
    supervisor: null,
    controlStandard: null,
    riskLevel: null,
    riskInfo: null,
    riskRelateId: null,
    auditor: null,
    riskDescribe: null,
    riskConseq: null,
    controlMeasure: null,
    remark: null,
    createBy: null,
    createTime: null,
    updateBy: null,
    updateTime: null,
  };
  proxy.resetForm("riskLibraryRef");
}
function editreset() {
  editform.value = {
    id: null,
    riskName: null,
    riskType: null,
    supervisor: null,
    controlStandard: null,
    riskLevel: null,
    riskInfo: null,
    riskRelateId: null,
    auditor: null,
    riskDescribe: null,
    riskConseq: null,
    controlMeasure: null,
    remark: null,
    createBy: null,
    createTime: null,
    updateBy: null,
    updateTime: null,
  };
  proxy.resetForm("riskLibraryRef");
}
/** 搜索按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// 多选框选中数据
function handleSelectionChange(selection) {
  ids.value = selection.map((item) => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 新增按钮操作 */
function handleAdd() {
  addreset();
  addopen.value = true;
  title.value = "新增风险";
}

/** 编辑按钮操作 */
function handleUpdate(row) {
  editreset();
  const _id = row.id || ids.value;
  getRiskLibrary(_id).then((response) => {
    editform.value = response.data;
    editopen.value = true;
    title.value = "编辑风险";
  });
}

/** 查看风险详情按钮操作 */
function handleMore(row) {
  const _id = row.id || ids.value;
  getRiskLibrary(_id).then((response) => {
    moreform.value = response.data;
    moreopen.value = true;
  });
}

/** 提交按钮 */
function editsubmitForm() {
  updateRiskLibrary(editform.value).then((response) => {
    proxy.$modal.msgSuccess("编辑成功");
    editopen.value = false;
    getList();
  });
}
function addsubmitForm() {
  addRiskLibrary(addform.value).then((response) => {
    proxy.$modal.msgSuccess("新增成功");
    addopen.value = false;
    getList();
  });
}

/** 删除按钮操作 */
function handleDelete(row) {
  const _ids = row.id || ids.value;
  proxy.$modal
    .confirm('是否确认删除风险库编号为"' + _ids + '"的数据项？')
    .then(function () {
      return delRiskLibrary(_ids);
    })
    .then(() => {
      getList();
      proxy.$modal.msgSuccess("删除成功");
    })
    .catch(() => {});
}

/** 导出按钮操作 */
function handleExport() {
  proxy.download(
    "risk/riskLibrary/export",
    {
      ...queryParams.value,
    },
    `riskLibrary_${new Date().getTime()}.xlsx`
  );
}

getList();
</script>