<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      ref="queryRef"
      :inline="true"
      v-show="showSearch"
      label-width="100px"
    >
      <el-form-item label="风险项名称" prop="unverifiedRiskName">
        <el-input
          v-model="queryParams.unverifiedRiskName"
          placeholder="请输入风险项名称"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="风险名称" prop="riskId">
        <el-select
          style="width: 220px"
          v-model="queryParams.riskId"
          placeholder="请选择风险名"
          clearable
          @keyup.enter="handleQuery"
        >
          <el-option
            v-for="item in AllrisksName"
            :key="item.riskId"
            :label="item.riskName"
            :value="item.riskId"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="作业位置" prop="position">
        <el-select
          style="width: 220px"
          v-model="queryParams.position"
          placeholder="请选择作业位置"
          clearable
          @keyup.enter="handleQuery"
        >
          <el-option
            v-for="item in Allpositions"
            :key="item.positionId"
            :label="item.position"
            :value="item.positionId"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="风险类型" prop="riskType">
        <el-radio-group v-model="queryParams.riskType">
          <el-radio
            v-for="dict in risksType"
            :key="dict.value"
            :label="dict.value"
            :value="dict.value"
            >{{ dict.label }}</el-radio
          >
        </el-radio-group>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          icon="Search"
          @click="handleQuery"
          color="#03bd8a"
          style="text-shadow: 0 0 0.3px #fff"
          >查询</el-button
        >
        <el-button
          icon="Refresh"
          @click="resetQuery"
          style="text-shadow: 0 0 0.3px #606266"
          >重置</el-button
        >
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          color="#03bd8a"
          style="text-shadow: 0 0 0.3px #03bd8a"
          @click="handleAdd"
          v-hasPermi="['risk:riskPend:add']"
          >新增</el-button
        >
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="Download"
          @click="handleExport"
          v-hasPermi="['risk:riskPend:export']"
          >导出</el-button
        >
      </el-col>
      <right-toolbar
        v-model:showSearch="showSearch"
        @queryTable="getList"
      ></right-toolbar>
    </el-row>

    <el-table
      v-loading="loading"
      :data="riskPendList"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="30" align="center" />
      <el-table-column label="序号" width="60" align="center" type="index"/>
      <el-table-column
        label="风险项名称"
        width="180"
        align="center"
        prop="unverifiedRiskName"
      />
      <el-table-column
        label="风险名"
        width="180"
        align="center"
        prop="riskName"
      />
      <el-table-column
        label="风险类型"
        width="120"
        align="center"
        prop="riskType"
      />
      <el-table-column
        label="作业位置"
        width="180"
        align="center"
        prop="position"
      />
      <el-table-column
        label="巡查标准"
        width="200"
        align="center"
        prop="controlStandard"
      />
      <el-table-column label="备注" width="280" align="center" prop="remark" />
      <el-table-column
        label="操作"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            class="editButton"
            color="#06c08b"
            plain
            @click="handleUpdate(scope.row)"
            v-hasPermi="['risk:riskPend:edit']"
            >编辑</el-button
          >
          <el-button
            class="DelButton"
            color="#ff7b47"
            plain
            @click="handleDelete(scope.row)"
            v-hasPermi="['risk:riskPend:remove']"
            >删除</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 新增风险项对话框 -->
    <el-dialog :title="title" v-model="addopen" width="650px" append-to-body>
      <span class="Basic">| <span class="Mes">基本信息</span></span>

      <el-form
        ref="riskPendRef"
        :model="addform"
        :rules="rules"
        label-width="120px"
        style="padding-top: 20px; margin-left: -35px"
      >
        <el-form-item label="风险项名称" prop="unverifiedRiskName">
          <el-input
            v-model="addform.unverifiedRiskName"
            placeholder="请输入风险项名称"
          />
        </el-form-item>
        <el-form-item label="风险名" prop="riskId">
          <el-select
            v-model="addform.riskId"
            placeholder="请选择风险名"
            style="width: 240px"
          >
            <el-option
              v-for="item in AllrisksName"
              :key="item.riskId"
              :label="item.riskName"
              :value="item.riskId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="作业位置" prop="position">
          <el-select
            v-model="addform.position"
            placeholder="请选择作业位置"
            style="width: 240px"
          >
            <el-option
              v-for="item in Allpositions"
              :key="item.positionId"
              :label="item.position"
              :value="item.positionId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="巡查标准" prop="controlStandard">
          <el-input
            v-model="addform.controlStandard"
            type="textarea"
            placeholder="请输入内容"
          />
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input
            v-model="addform.remark"
            type="textarea"
            placeholder="请输入内容"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="addsubmitForm">确 定</el-button>
          <el-button @click="addcancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
    <!-- 编辑 -->
    <el-dialog :title="title" v-model="editopen" width="650px" append-to-body>
      <span class="Basic">| <span class="Mes">基本信息</span></span>
      <el-form
        ref="riskPendRef"
        :model="editform"
        :rules="rules"
        label-width="120px"
        style="padding-top: 20px; margin-left: -35px"
      >
        <el-form-item label="风险项名称" prop="unverifiedRiskName">
          <el-input
            v-model="editform.unverifiedRiskName"
            placeholder="请输入风险项名称"
          />
        </el-form-item>
        <el-form-item label="风险名" prop="riskId">
          <el-select
            v-model="editform.riskId"
            placeholder="请选择风险"
            style="width: 240px"
          >
            <el-option
              v-for="item in AllrisksName"
              :key="item.riskId"
              :label="item.riskName"
              :value="item.riskId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="风险类型" prop="riskType">
          <el-select
            v-model="editform.riskType"
            placeholder="请选择风险类型"
            style="width: 240px"
          >
            <el-option
              v-for="item in risksType"
              :key="item.value"
              :label="item.value"
              :value="item.value"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="作业位置" prop="position">
          <el-select
            v-model="editform.position"
            placeholder="请选择作业位置"
            style="width: 240px"
          >
            <el-option
              v-for="item in Allpositions"
              :key="item.positionId"
              :label="item.position"
              :value="item.positionId"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="巡查标准" prop="controlStandard">
          <el-input
            v-model="editform.controlStandard"
            type="textarea"
            placeholder="请输入巡查标准"
          />
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input
            v-model="editform.remark"
            type="textarea"
            placeholder="请输入内容"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="editsubmitForm">确 定</el-button>
          <el-button @click="editcancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>
  
  <script setup name="RiskPend">
import {
  listRiskPend,
  listRiskAll,
  listPatrolPointAll,
  getRiskPend,
  getRiskLibrary,
  delRiskPend,
  addRiskPend,
  updateRiskPend,
  getPoint,
} from "@/api/risk/riskPend";

const { proxy } = getCurrentInstance();

const riskPendList = ref([]);
const riskId = ref([]);
const risksName = ref([]);
const AllrisksName = ref([]);
const positionId = ref([]);
const positions = ref([]);
const Allpositions = ref([]);

const addopen = ref(false);
const editopen = ref(false);

const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");

const data = reactive({
  addform: {},
  editform: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    unverifiedRiskName: null,
    riskId: null,
    riskType: null,
    position: null,
  },
  rules: {
    unverifiedRiskName: [
      { required: true, message: "待查项名称不能为空", trigger: "blur" },
    ],
    riskId: [
      { required: true, message: "关联风险id不能为空", trigger: "blur" },
    ],
    position: [
      { required: true, message: "作业位置名不能为空", trigger: "blur" },
    ],
  },
});

const { queryParams, addform, editform, rules } = toRefs(data);
const risksType = ref([
  {
    value: "作业风险",
    label: "作业风险",
  },
  {
    value: "生产现场风险",
    label: "生产现场风险",
  },
  {
    value: "设备风险",
    label: "设备风险",
  },
  {
    value: "其他",
    label: "其他",
  },
]);
/** 查询风险项管理列表 */
async function getList() {
  loading.value = true;
  try {
    const response = await listRiskPend(queryParams.value);
    riskPendList.value = response.rows;
    total.value = response.total;

    riskId.value = response.rows.map((row) => row.riskId);
    // position 是位置名称字符串，不是 ID，直接使用去重后的位置名称
    const uniquePositions = [...new Set(response.rows.map((row) => row.position).filter(p => p))];
    positions.value = uniquePositions.map((position, index) => ({
      positionId: index + 1,
      position: position
    }));

    await queryRiskNamesForIds(riskId.value);
    loading.value = false;
  } catch (error) {
    console.error("获取任务列表失败:", error);
    loading.value = false;
  }
}
async function getListAll() {
  try {
    const response1 = await listRiskAll();
    AllrisksName.value = response1.rows.map((riskName, riskId) => {
      return {
        riskName: riskName.riskName,
        riskId: riskId + 1,
      };
    });

    const response2 = await listPatrolPointAll();
    Allpositions.value = response2.rows.map((position, id) => {
      return {
        position: position.position,
        positionId: id + 1,
      };
    });
    console.log(Allpositions.value);
  } catch (error) {
    console.error("获取列表失败:", error);
    loading.value = false;
  }
}
// 逐一查询风险库并更新 taskList
async function queryRiskNamesForIds(ids) {
  const promises = ids.map(async (id) => {
    const response = await getRiskLibrary(id);
    handleSingleRiskLibraryResponse(response.data, id);
  });

  await Promise.all(promises).catch((errors) =>
    console.error("部分请求失败:", errors)
  );
}
async function queryPositionsForIds(ids) {
  const promises = ids.map(async (id) => {
    const response = await getPoint(id);
    handleSingleGetPointResponse(response.data, id);
  });

  await Promise.all(promises).catch((errors) =>
    console.error("部分请求失败:", errors)
  );
}
// 处理单个风险库响应数据
function handleSingleRiskLibraryResponse(data, riskIdItem) {
  if (data && data.riskName) {
    const existingRiskIndex = risksName.value.findIndex(
      (item) => item.riskId === riskIdItem
    );
    if (existingRiskIndex === -1) {
      risksName.value.push({ riskId: riskIdItem, riskName: data.riskName });
    } else {
      risksName.value[existingRiskIndex].riskName = data.riskName;
    }

    riskPendList.value.forEach((task) => {
      if (task.riskId === riskIdItem) {
        task.riskName = data.riskName;
      }
    });
  }
}
function handleSingleGetPointResponse(data, positionIdItem) {
  if (data && data.position) {
    const existingRiskIndex = positions.value.findIndex(
      (item) => item.positionId === positionIdItem
    );
    if (existingRiskIndex === -1) {
      positions.value.push({
        positionId: positionIdItem,
        position: data.position,
      });
    } else {
      positions.value[existingRiskIndex].position = data.position;
    }

    riskPendList.value.forEach((task) => {
      if (task.position === positionIdItem) {
        task.position = data.position;
      }
    });
  }
}
// 取消按钮
function addcancel() {
  addopen.value = false;
  addreset();
}
function editcancel() {
  editopen.value = false;
  editreset();
}

// 表单重置
function addreset() {
  addform.value = {
    id: null,
    unverifiedRiskName: null,
    riskId: null,
    riskType: null,
    admin: null,
    controlStandard: null,
    position: null,
    remark: null,
    createBy: null,
    createTime: null,
    updateBy: null,
    updateTime: null,
  };
  proxy.resetForm("riskPendRef");
}
function editreset() {
  editform.value = {
    id: null,
    unverifiedRiskName: null,
    riskId: null,
    riskType: null,
    admin: null,
    controlStandard: null,
    position: null,
    remark: null,
    createBy: null,
    createTime: null,
    updateBy: null,
    updateTime: null,
  };
  proxy.resetForm("riskPendRef");
}
/** 搜索按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
  getListAll();
}

/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// 多选框选中数据
function handleSelectionChange(selection) {
  ids.value = selection.map((item) => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 新增按钮操作 */
function handleAdd() {
  addreset();
  addopen.value = true;
  title.value = "新增风险项";
}

/** 编辑按钮操作 */
function handleUpdate(row) {
  editreset();
  const _id = row.id || ids.value;
  getRiskPend(_id).then((response) => {
    editform.value = response.data;
    editopen.value = true;
    title.value = "编辑风险项";
  });
}

/** 提交按钮 */
function addsubmitForm() {
  addRiskPend(addform.value).then((response) => {
    proxy.$modal.msgSuccess("新增成功");
    addopen.value = false;
    getList();
    getListAll();
  });
}
function editsubmitForm() {
  updateRiskPend(editform.value).then((response) => {
    proxy.$modal.msgSuccess("编辑成功");
    editopen.value = false;
    getList();
    getListAll();
  });
}

/** 删除按钮操作 */
function handleDelete(row) {
  const _ids = row.id || ids.value;
  proxy.$modal
    .confirm('是否确认删除风险项编号为"' + _ids + '"的数据项？')
    .then(function () {
      return delRiskPend(_ids);
    })
    .then(() => {
      getList();
      getListAll();
      proxy.$modal.msgSuccess("删除成功");
    })
    .catch(() => {});
}

/** 导出按钮操作 */
function handleExport() {
  proxy.download(
    "risk/riskPend/export",
    {
      ...queryParams.value,
    },
    `riskPend_${new Date().getTime()}.xlsx`
  );
}

getList();
getListAll();
</script>
  