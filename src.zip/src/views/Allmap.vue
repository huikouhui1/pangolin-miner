<template>
  <div class="map-container" ref="mapContainer">
    <!-- Loading overlay -->
    <div v-if="isLoading" class="loading-overlay">
      <div class="loading-content">
        <div class="spinner"></div>
        <div class="loading-text">{{ loadingMessage }}</div>
        <button v-if="loadError" class="retry-button" @click="retryLoading">重试</button>
      </div>
    </div>

    <!-- 页面加载时直接显示的提示，5秒后消失 -->
    <div v-if="showHint" class="zoom-hint">
      🔍 请将光标对着地图,按住 <strong>Ctrl</strong> 键并滚动鼠标放大地图后启用地图其他功能,防止渲染压力太大!!!
    </div>

    <!-- 地图 iframe -->
    <iframe
        :key="iframeKey"
        :src="mapUrl"
        class="map-frame"
        allowfullscreen
        ref="mapIframe"
        @load="handleIframeLoad"
        sandbox="allow-same-origin allow-scripts allow-popups allow-forms"
        loading="eager"
    ></iframe>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue';

const mapUrl = 'https://maps.clb.org.hk/?i18n_language=zh_CN&map=2&startDate=2024-11&endDate=2025-05';
const mapContainer = ref(null);
const mapIframe = ref(null);
const isLoading = ref(true);
const loadError = ref(false);
const loadingMessage = ref('加载地图中...');
const iframeKey = ref(Date.now());
const showHint = ref(false);

let loadingTimeout = null;
let hintTimeout = null;

const handleWheel = (event) => {
  if (!event.ctrlKey) {
    event.preventDefault();
    return;
  }
  event.preventDefault();
  try {
    const iframeWindow = mapIframe.value.contentWindow;
    const wheelEvent = new WheelEvent('wheel', {
      deltaX: event.deltaX,
      deltaY: event.deltaY,
      deltaZ: event.deltaZ,
      deltaMode: event.deltaMode,
      ctrlKey: true,
      bubbles: true,
      cancelable: true
    });
    iframeWindow.dispatchEvent(wheelEvent);
  } catch (error) {
    console.error('无法转发滚轮事件:', error);
  }
};

const startLoadingTimeout = () => {
  clearTimeout(loadingTimeout);
  loadingTimeout = setTimeout(() => {
    // 只有在仍在加载状态时才显示超时错误
    if (isLoading.value) {
      loadError.value = true;
      loadingMessage.value = '加载超时，可能原因：\n1. 网络连接问题\n2. 外部地图服务不可用\n3. 服务器响应慢\n请检查网络或点击重试';
      console.warn('地图加载超时（15秒内 load 事件未触发）:', mapUrl);
      // 注意：由于跨域限制，无法检测 iframe 内容，只能依赖 load 事件
    }
  }, 15000);
};

const handleIframeLoad = () => {
  console.log('iframe load 事件触发 - 地图应该已加载完成');
  clearTimeout(loadingTimeout);
  
  // 由于跨域限制，无法访问 iframe 内容来验证加载状态
  // 但 load 事件已触发，说明 iframe 已经加载完成
  // 延迟一点时间，给地图一些渲染时间
  setTimeout(() => {
    isLoading.value = false;
    loadError.value = false;
    try {
      mapIframe.value?.focus();
    } catch (e) {
      // 跨域限制，可能无法 focus，这是正常的
    }
    console.log('地图加载完成（load 事件已触发）');
  }, 500); // 延迟 500ms，给地图一些渲染时间
};

const retryLoading = () => {
  loadError.value = false;
  loadingMessage.value = '加载地图中...';
  iframeKey.value = Date.now();
  startLoadingTimeout();
};

onMounted(() => {
  console.log('地图组件挂载，URL:', mapUrl);
  // 页面一加载就显示提示，10秒后自动隐藏
  showHint.value = true;
  hintTimeout = setTimeout(() => {
    showHint.value = false;
  }, 10000);

  mapContainer.value?.addEventListener('wheel', handleWheel, {passive: false});
  
  // 检查 iframe 是否可用
  if (!mapIframe.value) {
    console.error('iframe 元素未找到');
    loadError.value = true;
    loadingMessage.value = '地图框架初始化失败';
    return;
  }
  
  startLoadingTimeout();
  
  // 注意：由于跨域限制，无法通过轮询检查 iframe 内容
  // 只能依赖 load 事件来判断加载状态
  // 如果 load 事件在 15 秒内未触发，会显示超时错误
});

onUnmounted(() => {
  mapContainer.value?.removeEventListener('wheel', handleWheel);
  clearTimeout(loadingTimeout);
  clearTimeout(hintTimeout);
});
</script>

<style scoped>
.map-container {
  width: 100%;
  height: 100vh;
  position: relative;
  overflow: hidden;
  background-color: black;
}

.map-frame {
  width: 100%;
  height: 100%;
  border: none;
}

.loading-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.6);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 10;
}

.loading-content {
  text-align: center;
  padding: 20px;
  border-radius: 8px;
}

.loading-text {
  margin-top: 15px;
  font-size: 16px;
  color: #fff;
}

.spinner {
  width: 40px;
  height: 40px;
  margin: 0 auto;
  border: 4px solid #444;
  border-top-color: #00bfff;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.retry-button {
  margin-top: 15px;
  padding: 10px 20px;
  background-color: #ff4d4f;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

/* Update the zoom-hint class to position it at the top */
.zoom-hint {
  position: absolute;
  top: 20px; /* Changed from bottom: 20px */
  left: 50%;
  transform: translateX(-50%);
  background-color: rgba(255, 255, 255, 0.95);
  color: #333;
  padding: 12px 20px;
  border-radius: 8px;
  font-size: 14px;
  z-index: 100;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  animation: fadeInOut 5s ease-out;
  pointer-events: none;
}

/* Update the animation to slide from top */
@keyframes fadeInOut {
  0% {
    opacity: 0;
    transform: translateX(-50%) translateY(-20px);
  }
  10% {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
  }
  90% {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
  }
  100% {
    opacity: 0;
    transform: translateX(-50%) translateY(-20px);
  }
}
</style>
