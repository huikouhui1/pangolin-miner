<template>
  <div class="scene-page">
    <div ref="mapRef" class="map-root"></div>

    <!-- 左上角信息面板 -->
    <div class="info-panel">
      <div class="panel-title">智慧矿山巡检系统</div>
      <div class="panel-desc">
        当前模式：点击矿山场景添加巡检点，至少添加 2 个点后可开始巡检
      </div>
      <div class="panel-status">
        <span class="status-dot"></span>
        巡检点数量：{{ patrolPoints.length }}
      </div>
    </div>

    <!-- 右上角操作面板 -->
    <div class="map-tools">
      <button class="tool-btn primary" @click="locateRobot">定位机器人</button>
      <button class="tool-btn" @click="flyToScene">重置到矿山</button>
      <button class="tool-btn success" @click="startPatrol">开始巡检</button>
      <button class="tool-btn danger" @click="clearPatrol">清空巡检点</button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from "vue"

const mars3d = window.mars3d
const Cesium = window.Cesium

const mapRef = ref(null)

// ===== 模型路径 =====
const SCENE_MODEL_URL = "/models/scene_gltf/scene_out/scene.gltf"
const ROBOT_MODEL_URL = "/models/巡检机器人3.glb"

// ===== 场景中心 =====
const sceneCenter = [117.21927, 31.84095, 2]

// ===== 模型缩放 =====
const ROBOT_MODEL_SCALE = 20

let map = null
let modelLayer = null
let routeLayer = null
let robotLayer = null

let sceneModel = null
let robotAnchor = null
let robotModel = null

const patrolPoints = ref([])
let patrolRouteGraphic = null
let patrolTimer = null
let currentSegmentIndex = 0
let segmentProgress = 0

const initMap = () => {
  if (!mapRef.value) return

  map = new mars3d.Map(mapRef.value, {
    scene: {
      center: {
        lat: 31.84095,
        lng: 117.21927,
        alt: 1200,
        heading: 343,
        pitch: -45
      },
      fxaa: true,
      showSkyBox: false,
      showSkyAtmosphere: false,
      fog: false
    },
    control: {
      geocoder: false,
      homeButton: true,
      sceneModePicker: false,
      navigationHelpButton: false,
      fullscreenButton: true,
      baseLayerPicker: false,
      timeline: false,
      animation: false
    },
    terrain: { show: false },
    basemaps: []
  })

  modelLayer = new mars3d.layer.GraphicLayer()
  routeLayer = new mars3d.layer.GraphicLayer()
  robotLayer = new mars3d.layer.GraphicLayer()

  map.addLayer(modelLayer)
  map.addLayer(routeLayer)
  map.addLayer(robotLayer)

  bindMapClick()
}

const bindMapClick = () => {
  if (!map) return

  map.on(mars3d.EventType.click, (event) => {
    if (!event.cartesian) return

    const point = mars3d.LngLatPoint.fromCartesian(event.cartesian)
    if (!point) return

    const position = [point.lng, point.lat, point.alt || sceneCenter[2]]
    patrolPoints.value.push(position)

    if (patrolPoints.value.length === 1) {
      updateRobotPosition(position)
    }

    drawPatrolRoute()
  })
}

const drawPatrolRoute = () => {
  if (!routeLayer) return

  routeLayer.clear()
  patrolRouteGraphic = null

  if (patrolPoints.value.length >= 2) {
    patrolRouteGraphic = new mars3d.graphic.PolylineEntity({
      positions: patrolPoints.value,
      style: {
        width: 6,
        color: "#00e5ff"
      }
    })
    routeLayer.addGraphic(patrolRouteGraphic)
  }

  patrolPoints.value.forEach((position, index) => {
    const pointGraphic = new mars3d.graphic.PointEntity({
      position,
      style: {
        pixelSize: 10,
        color: "#ffeb3b",
        outline: true,
        outlineColor: "#333",
        outlineWidth: 2,
        label: {
          text: `P${index + 1}`,
          color: "#ffffff",
          font_size: 16,
          outline: true,
          outlineColor: "#000000",
          pixelOffsetY: -18
        }
      }
    })
    routeLayer.addGraphic(pointGraphic)
  })
}

const loadSceneModel = () => {
  if (!modelLayer) return

  if (sceneModel) {
    modelLayer.removeGraphic(sceneModel)
    sceneModel = null
  }

  sceneModel = new mars3d.graphic.ModelPrimitive({
    position: sceneCenter,
    style: {
      url: SCENE_MODEL_URL,
      scale: 50,
      backFaceCulling: false,
      runAnimations: true
    }
  })

  modelLayer.addGraphic(sceneModel)

  const ready = sceneModel.readyPromise
  if (ready && typeof ready.then === "function") {
    ready.then(() => setTimeout(flyToScene, 800)).catch(flyToScene)
  } else {
    flyToScene()
  }
}

const loadRobot = () => {
  if (!robotLayer) return

  robotLayer.clear()

  robotAnchor = new mars3d.graphic.PointEntity({
    position: sceneCenter,
    style: {
      pixelSize: 12,
      color: "#00ff88",
      outline: true,
      outlineColor: "#ffffff",
      outlineWidth: 2
    }
  })

  robotModel = new mars3d.graphic.ModelPrimitive({
    position: sceneCenter,
    style: {
      url: ROBOT_MODEL_URL,
      scale: ROBOT_MODEL_SCALE,
      heading: 0,
      pitch: 0,
      roll: 0
    }
  })

  robotLayer.addGraphic(robotAnchor)
  robotLayer.addGraphic(robotModel)
}

const updateRobotPosition = (position) => {
  if (!robotAnchor || !robotModel) return

  robotAnchor.position = position
  robotModel.position = position
}

const updateRobotHeading = (start, end) => {
  if (!robotModel) return

  const dx = end[0] - start[0]
  const dy = end[1] - start[1]
  const rad = Math.atan2(dx, dy)
  let deg = Cesium.Math.toDegrees(rad)
  if (deg < 0) deg += 360

  robotModel.style.heading = deg
}

const interpolatePosition = (start, end, t) => {
  return [
    start[0] + (end[0] - start[0]) * t,
    start[1] + (end[1] - start[1]) * t,
    start[2] + (end[2] - start[2]) * t
  ]
}

const stopPatrolTimer = () => {
  if (patrolTimer) {
    clearInterval(patrolTimer)
    patrolTimer = null
  }
}

const startPatrol = () => {
  if (patrolPoints.value.length < 2) {
    alert("请至少添加 2 个巡检点")
    return
  }

  stopPatrolTimer()

  currentSegmentIndex = 0
  segmentProgress = 0

  patrolTimer = setInterval(() => {
    const s = patrolPoints.value[currentSegmentIndex]
    const e = patrolPoints.value[currentSegmentIndex + 1]
    if (!e) return

    updateRobotHeading(s, e)

    segmentProgress += 0.02

    if (segmentProgress >= 1) {
      segmentProgress = 0
      currentSegmentIndex++
      if (currentSegmentIndex >= patrolPoints.value.length - 1) {
        stopPatrolTimer()
        return
      }
    }

    const pos = interpolatePosition(
      patrolPoints.value[currentSegmentIndex],
      patrolPoints.value[currentSegmentIndex + 1],
      segmentProgress
    )

    updateRobotPosition(pos)
  }, 50)
}

const clearPatrol = () => {
  stopPatrolTimer()
  patrolPoints.value = []
  routeLayer.clear()

  updateRobotPosition(sceneCenter)
}

const locateRobot = () => {
  if (!map || !robotAnchor) return
  map.flyToGraphic(robotAnchor, { radius: 120 })
}

const flyToScene = () => {
  if (!map) return
  map.flyToPoint([117.21927, 31.84095, 500], { pitch: -45 })
}

onMounted(() => {
  initMap()
  loadSceneModel()
  loadRobot()
})

onUnmounted(() => {
  stopPatrolTimer()
  map?.destroy()
})
</script>

<style scoped>
.scene-page {
  height: calc(100vh - 84px);
  position: relative;
  overflow: hidden;
  background: linear-gradient(180deg, #081221 0%, #0b1d35 100%);
}

.map-root {
  width: 100%;
  height: 100%;
}

/* 左上角信息面板 */
.info-panel {
  position: absolute;
  top: 20px;
  left: 20px;
  min-width: 320px;
  max-width: 420px;
  padding: 18px 20px;
  background: rgba(7, 22, 43, 0.72);
  border: 1px solid rgba(64, 158, 255, 0.35);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.28);
  backdrop-filter: blur(10px);
  border-radius: 14px;
  color: #fff;
  z-index: 10;
}

.panel-title {
  font-size: 20px;
  font-weight: 700;
  color: #4db3ff;
  margin-bottom: 10px;
  letter-spacing: 1px;
}

.panel-desc {
  font-size: 14px;
  line-height: 1.7;
  color: rgba(255, 255, 255, 0.88);
  margin-bottom: 12px;
}

.panel-status {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 12px;
  background: rgba(0, 229, 255, 0.08);
  border: 1px solid rgba(0, 229, 255, 0.2);
  border-radius: 20px;
  font-size: 13px;
  color: #d9f6ff;
}

.status-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #00ff88;
  box-shadow: 0 0 8px #00ff88;
}

/* 右上角按钮区 */
.map-tools {
  position: absolute;
  top: 20px;
  right: 20px;
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
  justify-content: flex-end;
  z-index: 10;
}

.tool-btn {
  padding: 10px 18px;
  border: 1px solid rgba(255, 255, 255, 0.16);
  border-radius: 10px;
  background: rgba(15, 34, 62, 0.78);
  color: #eaf4ff;
  font-size: 14px;
  cursor: pointer;
  backdrop-filter: blur(8px);
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.22);
  transition: all 0.25s ease;
}

.tool-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.28);
  border-color: rgba(77, 179, 255, 0.5);
  color: #ffffff;
}

.tool-btn.primary {
  background: linear-gradient(135deg, #1677ff, #409eff);
  border: none;
}

.tool-btn.success {
  background: linear-gradient(135deg, #12b981, #34d399);
  border: none;
}

.tool-btn.danger {
  background: linear-gradient(135deg, #ef4444, #f87171);
  border: none;
}

/* 适配小屏 */
@media (max-width: 768px) {
  .info-panel {
    min-width: auto;
    width: calc(100% - 32px);
    left: 16px;
    top: 16px;
    padding: 14px 16px;
  }

  .map-tools {
    top: auto;
    bottom: 20px;
    right: 16px;
    left: 16px;
    justify-content: center;
  }

  .tool-btn {
    flex: 1 1 40%;
    min-width: 120px;
  }
}
</style>