<template>
  <div class="embed-page">
    <!-- 下面是你的项目页面 -->
    <div class="iframe-box">
      <iframe
          :src="projectUrl"
          class="iframe-full"
          allowfullscreen
          loading="lazy"
      ></iframe>
    </div>
  </div>
</template>

<script setup>
const projectUrl = 'http://81.71.3.20:7080/#/project/items'
</script>

<style scoped>
.embed-page {
  display: flex;
  flex-direction: column;
  height: 100vh;
}

.iframe-box {
  flex: 1;
  overflow: hidden;
}

.iframe-full {
  width: 100%;
  height: 100%;
  border: none;
  display: block;
}
</style>
