<template>
  <div class="box">
    <div class="top">
      <div class="top-title">
        <span>智慧矿山大屏</span>
      </div>
      <div class="top-detail">
        <div class="top-detail-item" style="color: #ff0000">
          A<span>{{ a }}项</span>
        </div>
        <div class="top-detail-item" style="color: #ff4800">
          B<span>{{ b }}项</span>
        </div>
        <div class="top-detail-item" style="color: #ff9000">
          C<span>{{ c }}项</span>
        </div>
        <div class="top-detail-item" style="color: #ffbc00">
          D<span>{{ d }}项</span>
        </div>
        <div style="font-weight: 800; margin-right: -60px">|</div>
      </div>

      <div class="top-people">
        <div class="top-people-item">
          <span class="top-people-item-num">总人数</span>
          <span>{{ userNum }}<span class="top-people-item-num"> 人</span></span>
        </div>
        <div class="top-people-item">
          <span class="top-people-item-num">管理员</span>
          <span>{{ admin }}<span class="top-people-item-num"> 人</span></span>
        </div>
        <div class="top-people-item">
          <span class="top-people-item-num">安全员</span>
          <span>{{ security }}<span class="top-people-item-num"> 人</span></span>
        </div>
      </div>
    </div>

    <div class="dashboard-container">
      <div class="dashboard-wrapper">
        <!-- Dashboard 1 -->
        <div class="dashboard"
             :class="{
               'expanded': expandedDashboard === 1,
               'hidden': expandedDashboard !== null && expandedDashboard !== 1
             }"
             @click="handleClick(1)"
             @dblclick="handleDoubleClick(1)">
          <div class="dashboard-header">
            <span>安全监测指标分析</span>
          </div>
          <div class="iframe-container">
            <iframe
                src="http://81.71.3.20:7080/#/chart/preview/1079188885055082496"
                frameborder="0"
            ></iframe>
          </div>
          <div class="close-btn" v-if="expandedDashboard === 1" @click.stop="closeFullscreen">×</div>
        </div>

        <!-- Dashboard 2 -->
        <div class="dashboard"
             :class="{
               'expanded': expandedDashboard === 2,
               'hidden': expandedDashboard !== null && expandedDashboard !== 2
             }"
             @click="handleClick(2)"
             @dblclick="handleDoubleClick(2)">
          <div class="dashboard-header">
            <span>风险管控数据分析</span>
          </div>
          <div class="iframe-container">
            <iframe
                src="http://81.71.3.20:7080/#/chart/preview/1076826237009268736"
                frameborder="0"
            ></iframe>
          </div>
          <div class="close-btn" v-if="expandedDashboard === 2" @click.stop="closeFullscreen">×</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from "vue";
import { listRiskLibrary } from "@/api/risk/riskLibrary";
import { listUser } from "@/api/system/user";
import { list100, list101 } from "@/api/system/role";

// 仪表盘状态管理
const expandedDashboard = ref(null);
let clickTimer = null;

// 单击处理（容器内放大）
const handleClick = (dashboardId) => {
  if (clickTimer) {
    clearTimeout(clickTimer);
    clickTimer = null;
    return;
  }

  clickTimer = setTimeout(() => {
    expandedDashboard.value = expandedDashboard.value === dashboardId ? null : dashboardId;
    clickTimer = null;
  }, 200);
};

// 双击处理（新标签页打开）
const handleDoubleClick = (dashboardId) => {
  clearTimeout(clickTimer);
  clickTimer = null;

  const urls = {
    1: 'http://81.71.3.20:7080/#/chart/preview/1076826090351235072',
    2: 'http://81.71.3.20:7080/#/chart/preview/1076826237009268736'
  };

  // 创建一个临时的 a 元素来模拟用户点击
  const newTab = document.createElement('a');
  newTab.href = urls[dashboardId];
  newTab.target = '_blank';
  newTab.rel = 'noopener noreferrer';

  // 将元素添加到页面并触发点击
  document.body.appendChild(newTab);
  newTab.click();

  // 清理创建的元素
  setTimeout(() => {
    document.body.removeChild(newTab);
  }, 100);
};

// 关闭放大状态
const closeFullscreen = (event) => {
  if (event) event.stopPropagation();
  expandedDashboard.value = null;
};

// ESC键监听
const handleKeyDown = (event) => {
  if (event.key === 'Escape') {
    closeFullscreen();
  }
};

// 生命周期钩子
onMounted(() => {
  document.addEventListener('keydown', handleKeyDown);
});

onUnmounted(() => {
  document.removeEventListener('keydown', handleKeyDown);
});

// 数据获取逻辑
const a = ref(0);
const b = ref(0);
const c = ref(0);
const d = ref(0);
const userNum = ref(0);
const admin = ref(0);
const security = ref(0);

// 初始化数据请求
const initData = async () => {
  try {
    // 风险数据
    const requests = [
      listRiskLibrary({ riskLevel: "A" }),
      listRiskLibrary({ riskLevel: "B" }),
      listRiskLibrary({ riskLevel: "C" }),
      listRiskLibrary({ riskLevel: "D" }),
      listUser({}),
      list101(),
      list100()
    ];

    const [
      resA, resB, resC, resD,
      resUser, resAdmin, resSecurity
    ] = await Promise.all(requests);

    a.value = resA.total;
    b.value = resB.total;
    c.value = resC.total;
    d.value = resD.total;
    userNum.value = resUser.total;
    admin.value = resAdmin.data;
    security.value = resSecurity.data;
  } catch (error) {
    console.error('数据加载失败:', error);
  }
};

// 初始化执行
initData();
</script>

<style scoped lang="scss">
.box {
  width: 100%;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background-color: #f5f7fa;
  overflow: hidden;

  .top {
    display: flex;
    justify-content: space-between;
    width: 100%;
    height: 10%;
    min-height: 80px;
    padding: 10px 60px;
    background-image: linear-gradient(to bottom, #0044a0, #0052c5);
    border-bottom: 0.5px solid #dfdfdf;

    .top-title {
      //居中
      display: flex;
      align-items: center;
      font-size: 28px;
      color: #ffffff;
      font-weight: 800;
      text-shadow: 0 0 0.5px #ffffff;
    }

    .top-detail {
      display: flex;
      align-items: center;
      font-size: 18px;
      color: #f1f1f1;

      &-item {
        font-size: 50px;
        font-weight: 800;
        margin-right: 50px;

        span {
          color: #ffffff;
          margin-left: 15px;
          font-size: 25px;
        }
      }
    }

    .top-people {
      display: flex;
      align-items: center;
      color: #ffffff;

      &-item {
        margin-left: 50px;
        font-size: 25px;
        font-weight: 800;

        &-num {
          font-size: 18px;
          color: #e9e9e9;
          font-weight: 400;
        }
      }
    }
  }

  .dashboard-container {
    flex: 1;
    padding: 10px;
    background-color: #f0f2f5;
    display: flex;
    flex-direction: column;

    .dashboard-wrapper {
      display: flex;
      gap: 16px;
      flex: 1;
      position: relative;

      .dashboard {
        flex: 1;
        border-radius: 8px;
        background: white;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        transition: all 0.3s ease;
        overflow: hidden;
        position: relative;
        display: flex;
        flex-direction: column;
        height: calc(100vh - 120px); /* Fixed height based on viewport */
        //height: calc(60vh - 20px); /* Fixed height based on viewport */

        &.expanded {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          z-index: 100;
          box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
        }

        &.hidden {
          opacity: 0;
          pointer-events: none;
        }

        &-header {
          padding: 10px 16px;
          background: linear-gradient(to right, #0052c5, #0076ff);
          color: white;
          font-size: 16px;
          font-weight: 500;
          height: 40px;
          display: flex;
          align-items: center;
          flex-shrink: 0;
        }

        .iframe-container {
          flex: 1;
          position: relative;
          overflow: hidden;
          height: calc(100% - 40px); /* Subtract header height */
        }

        iframe {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          border: none;
        }

        .close-btn {
          position: absolute;
          top: 12px;
          right: 12px;
          width: 32px;
          height: 32px;
          background: rgba(0, 0, 0, 0.6);
          color: white;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.2s ease;
          z-index: 101;

          &:hover {
            background: rgba(0, 0, 0, 0.8);
            transform: scale(1.1);
          }
        }

        &:hover:not(.expanded) {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
      }
    }
  }
}

/* Remove the media query for aspect ratio */
/* Media query for larger screens to optimize aspect ratio */
@media (min-width: 1200px) {
  .dashboard-wrapper {
    .dashboard {
      height: calc(100vh - 110px); /* Slightly taller on larger screens */
    }
  }
}

@keyframes fadeIn {
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
}

.expanded {
  animation: fadeIn 0.3s ease-out;
}
</style>
