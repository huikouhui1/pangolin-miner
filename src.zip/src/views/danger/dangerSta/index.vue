<template>
  <div class="all">
    <div class="all-top">
      <div class="all-top-left"><dangerCategroy></dangerCategroy></div>
      <div class="all-top-right"><dangerNumWeek></dangerNumWeek></div>
    </div>
    <div class="all-bottom"><dangerNumYear></dangerNumYear></div>
  </div>
</template>

<script setup>
import dangerCategroy from "@/components/echarts/dangerSta/dangerCategroy.vue";
import dangerNumWeek from "../../../components/echarts/dangerSta/dangerNumWeek.vue";
import dangerNumYear from "../../../components/echarts/dangerSta/dangerNumYear.vue";
</script>

<style scoped lang="scss">
.all {
  padding: 25px 25px;
  height: 90.68vh;
  .all-top {
    display: flex;
    width: 100%;
    height: 41vh;
    margin-bottom: 30px;
    .all-top-left {
      width: 40%;
      height: 100%;
      margin-right: 30px;
      padding: 15px 20px;
      border-radius: 5px;
      box-shadow: 0 0 5px 2px #dddddd;
      background-color: #fff;
    }
    .all-top-right {
      width: 58%;
      height: 100%;
      padding: 15px 20px;
      border-radius: 5px;
      background-color: #fff;
      box-shadow: 0 0 5px 2px #dddddd;
    }
  }
  .all-bottom {
    width: 100%;
    height: 41vh;
    padding: 15px 20px;
    border-radius: 5px;
    box-shadow: 0 0 5px 2px #dddddd;
    background-color: #ffffff;
  }
}
</style>