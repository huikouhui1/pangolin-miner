<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      ref="queryRef"
      :inline="true"
      v-show="showSearch"
      label-width="80px"
    >
      <el-form-item label="隐患标题" prop="troubleTitle">
        <el-input
          v-model="queryParams.troubleTitle"
          placeholder="请输入隐患标题"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="隐患分类" prop="troubleClassify">
        <el-select
          v-model="queryParams.troubleClassify"
          placeholder="请选择隐患分类"
          clearable
          style="width: 215px"
        >
          <el-option
            v-for="dict in danger_category"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="隐患来源" prop="source">
        <el-select
          v-model="queryParams.source"
          placeholder="请选择隐患来源"
          clearable
          style="width: 215px"
        >
          <el-option
            v-for="dict in danger_origin"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="上传时间" prop="createTime">
        <el-date-picker
          clearable
          v-model="queryParams.createTime"
          type="date"
          value-format="YYYY-MM-DD"
          placeholder="请选择上传时间"
        >
        </el-date-picker>
      </el-form-item>
      <el-form-item label="处理状态" prop="status">
        <el-select
          v-model="queryParams.status"
          placeholder="请选择处理状态"
          clearable
          style="width: 215px"
        >
          <el-option
            v-for="dict in danger_handle_status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          icon="Search"
          color="#03bd8a"
          @click="handleQuery"
          style="text-shadow: 0 0 0.3px #fff"
          >查询</el-button
        >
        <el-button
          icon="Refresh"
          @click="resetQuery"
          style="text-shadow: 0 0 0.3px #606266"
          >重置</el-button
        >
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          color="#03bd8a"
          style="text-shadow: 0 0 0.3px #03bd8a"
          @click="handleAdd"
          v-hasPermi="['danger:dangerHandle:add']"
          >新增</el-button
        >
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="Download"
          @click="handleExport"
          v-hasPermi="['danger:dangerHandle:export']"
          >导出</el-button
        >
      </el-col>
      <right-toolbar
        v-model:showSearch="showSearch"
        @queryTable="getList"
      ></right-toolbar>
    </el-row>

    <el-table
      v-loading="loading"
      :data="dangerHandleList"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="30" align="center" />
      <el-table-column label="序号" width="60" align="center" type="index"/>
      <el-table-column
        label="隐患标题"
        width="250"
        align="center"
        prop="troubleTitle"
      />
      <el-table-column
        label="隐患来源"
        width="140"
        align="center"
        prop="source"
      >
        <template #default="scope">
          <dict-tag :options="danger_origin" :value="scope.row.source" />
        </template>
      </el-table-column>
      <el-table-column
        label="上传人"
        width="150"
        align="center"
        prop="userName"
      />
      <el-table-column
        label="上传时间"
        align="center"
        prop="createTime"
        width="150"
      >
        <template #default="scope">
          <span>{{ parseTime(scope.row.createTime, "{y}-{m}-{d}") }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="处理状态"
        width="130"
        align="center"
        prop="status"
      >
        <template #default="scope">
          <dict-tag
            :options="danger_handle_status"
            :value="scope.row.status"
            :style="getHandleStatusStyles(scope.row.status)"
          />
        </template> </el-table-column
      ><el-table-column
        label="隐患详情"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            class="moreButton"
            color="#3b87e0"
            plain
            @click="handleDangerMore(scope.row)"
            v-hasPermi="['danger:dangerHandle:dangermore']"
            >查看详情</el-button
          >
        </template>
      </el-table-column>
      <el-table-column
        label="操作"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            type="primary"
            class="editButton"
            plain
            @click="handleUpdate(scope.row)"
            v-hasPermi="['danger:dangerHandle:edit']"
            >编辑</el-button
          >
          <el-button
            class="DelButton"
            color="#ff7b47"
            plain
            @click="handleDelete(scope.row)"
            v-hasPermi="['danger:dangerHandle:remove']"
            >删除</el-button
          >
        </template>
      </el-table-column>
      <el-table-column
        label="处理结果"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            class="moreButton"
            color="#3b87e0"
            plain
            @click="handleDangerHandleResult(scope.row)"
            v-hasPermi="['danger:dangerHandle:dangerhandleresult']"
            >查看结果</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 新增隐患处理对话框 -->
    <el-dialog title="新增隐患" v-model="addopen" width="850px" append-to-body>
      <span class="Basic">| <span class="Mes">基本信息</span></span>
      <el-form
        ref="dangerHandleRef"
        :model="addform"
        :rules="rules"
        label-width="100px"
        style="margin-top: 20px"
      >
        <el-form-item label="隐患图片" prop="troubleImgPath">
          <el-upload
            v-model:file-list="addfileList"
            :action="uploadUrl"
            :headers="headers"
            list-type="picture-card"
            :on-preview="addhandlePreview"
            :before-remove="addbeforehandleRemove"
            :on-success="addhandleSuccess"
          >
            <el-icon><Plus /></el-icon>
          </el-upload>

          <el-dialog v-model="adddialogVisible">
            <img
              w-full
              style="width: 650px"
              :src="adddialogImageUrl"
              alt="Preview Image"
            />
          </el-dialog>
        </el-form-item>
        <el-form-item label="隐患标题" prop="troubleTitle">
          <el-input
            v-model="addform.troubleTitle"
            placeholder="请输入隐患标题"
          />
        </el-form-item>
        <el-form-item label="上传人" prop="creatorId">
          <el-select
            v-model="addform.creatorId"
            placeholder="请选择上传人"
            style="width: 245px"
          >
            <el-option
              v-for="(dict, index) in creator"
              :key="index"
              :label="dict"
              :value="index"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="隐患分类" prop="troubleClassify">
          <el-radio-group v-model="addform.troubleClassify">
            <el-radio
              v-for="dict in danger_category"
              :key="dict.value"
              :label="parseInt(dict.value)"
              >{{ dict.label }}</el-radio
            >
          </el-radio-group>
        </el-form-item>
        <el-form-item label="隐患描述" prop="troubleDesc">
          <el-input
            v-model="addform.troubleDesc"
            type="textarea"
            placeholder="请输入内容"
          />
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input
            v-model="addform.remark"
            type="textarea"
            placeholder="请输入内容"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="addsubmitForm">确 定</el-button>
          <el-button @click="addcancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
    <!-- 编辑隐患处理对话框 -->
    <el-dialog title="编辑隐患" v-model="editopen" width="850px" append-to-body>
      <span class="Basic">| <span class="Mes">基本信息</span></span>
      <el-form
        ref="dangerHandleRef"
        :model="editform"
        :rules="rules"
        label-width="100px"
        style="margin-top: 20px"
      >
        <el-form-item label="隐患图片" prop="troubleImgPath">
          <el-upload
            v-model:file-list="editfileList"
            :action="uploadUrl"
            :headers="headers"
            list-type="picture-card"
            :on-preview="edithandlePreview"
            :before-remove="editbeforehandleRemove"
            :on-success="edithandleSuccess"
          >
            <el-icon><Plus /></el-icon>
          </el-upload>

          <el-dialog v-model="editdialogVisible">
            <img
              w-full
              style="width: 650px"
              :src="editdialogImageUrl"
              alt="Preview Image"
            />
          </el-dialog>
        </el-form-item>
        <el-form-item label="隐患标题" prop="troubleTitle">
          <el-input
            v-model="editform.troubleTitle"
            placeholder="请输入隐患标题"
          />
        </el-form-item>
        <el-form-item label="上传人" prop="creatorId">
          <el-input
            disabled
            v-model="editform.createBy"
            placeholder="请输入上传人"
          />
        </el-form-item>
        <el-form-item label="上传时间" prop="createTime">
          <el-date-picker
            clearable
            v-model="editform.createTime"
            type="date"
            value-format="YYYY-MM-DD"
            placeholder="请选择上传时间"
          >
          </el-date-picker>
        </el-form-item>
        <el-form-item label="隐患分类" prop="troubleClassify">
          <el-radio-group v-model="editform.troubleClassify">
            <el-radio
              v-for="dict in danger_category"
              :key="dict.value"
              :label="parseInt(dict.value)"
              >{{ dict.label }}</el-radio
            >
          </el-radio-group>
        </el-form-item>
        <el-form-item label="隐患描述" prop="troubleDesc">
          <el-input
            v-model="editform.troubleDesc"
            type="textarea"
            placeholder="请输入内容"
          />
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input
            v-model="editform.remark"
            type="textarea"
            placeholder="请输入内容"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="editsubmitForm">确 定</el-button>
          <el-button @click="editcancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
    <!-- 隐患详情对话框 -->
    <el-dialog
      title="隐患详情"
      v-model="dangermoreopen"
      width="800px"
      append-to-body
    >
      <span class="Basic">| <span class="Mes">详细信息</span></span>
      <el-descriptions border column="2">
        <el-descriptions-item :span="2" label="隐患标题">{{
          dangermoreform.troubleTitle
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="隐患图片"
          ><el-image
            v-for="(url, index) in troubleImgPaths"
            :key="index"
            :src="url"
            :preview-src-list="troubleImgPaths"
            style="
              width: auto;
              height: auto;
              margin-right: 10px;
              display: inline-block;
            "
        /></el-descriptions-item>
        <el-descriptions-item :span="2" label="隐患描述">{{
          dangermoreform.troubleDesc
        }}</el-descriptions-item>
        <el-descriptions-item label="上传人">{{
          creatorUserName
        }}</el-descriptions-item>
        <el-descriptions-item label="上传时间">{{
          dangermoreform.createTime
        }}</el-descriptions-item>
        <el-descriptions-item label="处理状态"
          ><el-tag size="small" :style="tagStyle" effect="dark">{{
            statusText
          }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item :span="2" label="隐患分类">{{
          troubleClassifyText
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="隐患来源">{{
          sourceText
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="备注">{{
          dangermoreform.remark
        }}</el-descriptions-item>
      </el-descriptions>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="morecancel">确 定</el-button>
          <el-button @click="morecancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
    <!-- 处理结果对话框 -->
    <el-dialog
      title="处理结果"
      v-model="handleresultopen"
      width="800px"
      append-to-body
    >
      <span class="Basic">| <span class="Mes">详细信息</span></span>
      <el-descriptions border column="2">
        <el-descriptions-item :span="2" label="处理图片"
          ><el-image
            v-for="(url, index) in handleImgPaths"
            :key="index"
            :src="url"
            :preview-src-list="handleImgPaths"
            style="
              width: auto;
              height: auto;
              margin-right: 10px;
              display: inline-block;
            "
        /></el-descriptions-item>
        <el-descriptions-item label="处理人">{{
          handlerIdUserName
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="整改时间">{{
          handleresultform.rectifyTime
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="整改描述">{{
          handleresultform.rectifyDesc
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="备注">{{
          handleresultform.remark
        }}</el-descriptions-item>
      </el-descriptions>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="morecancel">确 定</el-button>
          <el-button @click="morecancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>
  
<script setup name="DangerHandle">
import {
  listDangerHandle,
  getDangerHandle,
  delDangerHandle,
  addDangerHandle,
  updateDangerHandle,
  getUser,
  listUser,
  deleteImg,
} from "@/api/danger/dangerHandle";
import { ElMessage } from "element-plus";

const uploadUrl = "/dev-api/rsm/oss/upload";
const headers = {
  Authorization: localStorage.getItem("token") || "",
};

const addList = [];
const addfileList = ref([]);
const adddialogImageUrl = ref("");
const adddialogVisible = ref(false);

const editfileList = ref([]);
const editdialogImageUrl = ref("");
const editdialogVisible = ref(false);
// 处理预览
const addhandlePreview = (file) => {
  adddialogImageUrl.value = file.url;
  adddialogVisible.value = true;
};
const addbeforehandleRemove = async (file, fileList) => {
  try {
    const deleteimg = { url: "" };
    deleteimg.url = file.response.data;
    const response = await deleteImg(deleteimg);
    if (response.code === 200) {
      addList.pop({ url: file.response.data });
      addform.value.troubleImgPath = addList.map((item) => item.url).join(",");
      ElMessage.success("图片删除成功");
    }
  } catch (err) {
    console.error(err);
  }
};
// 处理文件上传成功
const addhandleSuccess = async (response, file, fileList) => {
  try {
    if (response.code === 200) {
      addList.push({ url: response.data });
      addform.value.troubleImgPath = addList.map((item) => item.url).join(",");
      ElMessage.success("图片上传成功");
    }
  } catch (err) {
    console.error(err);
  }
};
// 处理预览
const edithandlePreview = (file) => {
  editdialogImageUrl.value = file.url;
  editdialogVisible.value = true;
};
// 处理文件移除
const editbeforehandleRemove = async (file, fileList) => {
  try {
    const deimg = { url: "" };
    deimg.url = file.url;
    const response = await deleteImg(deimg);
    if (response.code === 200) {
      editfileList.value.pop({ url: file.url });
      editform.value.troubleImgPath = editfileList.value
        .map((item) => item.url)
        .join(",");
      ElMessage.success("图片已删除，请确认修改");
    }
  } catch (err) {
    console.error(err);
  }
};
// 处理文件上传成功
const edithandleSuccess = async (response, file, fileList) => {
  try {
    if (response.code === 200) {
      editform.value.troubleImgPath = editform.value.troubleImgPath + "," + response.data;
      ElMessage.success("图片上传成功");
    }
  } catch (err) {
    console.error(err);
  }
};
const { proxy } = getCurrentInstance();
const { danger_category, danger_handle_status, danger_origin } = proxy.useDict(
  "danger_category",
  "danger_handle_status",
  "danger_origin"
);

const dangerHandleList = ref([]);
const creator = ref([]);
const creatorId = ref([]);
const creatorUserName = ref("");
const handlerIdUserName = ref("");

const addopen = ref(false);
const editopen = ref(false);
const dangermoreopen = ref(false);
const handleresultopen = ref(false);

const troubleImgPaths = ref([]);
const handleImgPaths = ref([]);

const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);

const data = reactive({
  addform: {},
  editform: {},
  dangermoreform: {},
  handleresultform: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    troubleTitle: null,
    status: null,
    troubleClassify: null,
    source: null,
    createTime: null,
  },
  rules: {
    troubleTitle: [
      { required: true, message: "隐患标题不能为空", trigger: "blur" },
    ],
    creatorId: [{ required: true, message: "上传人不能为空", trigger: "blur" }],
  },
});

const {
  queryParams,
  addform,
  editform,
  handleresultform,
  dangermoreform,
  rules,
} = toRefs(data);

/** 查询隐患处理列表 */
async function getList() {
  loading.value = true;
  try {
    const response = await listDangerHandle(queryParams.value);
    // Make a copy of the response data
    dangerHandleList.value = [...response.rows];
    
    // Debug the timestamps before sorting
    console.log("Before sorting:", dangerHandleList.value.map(item => ({id: item.id, createTime: item.createTime})));
    
    // Sort by createTime in descending order (newest first)
    dangerHandleList.value.sort((a, b) => {
      // Handle format "2024-09-08 20:47:51" properly
      // The format is already valid for Date parsing
      const dateA = new Date(a.createTime);
      const dateB = new Date(b.createTime);
      return dateB - dateA; // Descending order
    });
    
    // Debug the timestamps after sorting
    console.log("After sorting:", dangerHandleList.value.map(item => ({id: item.id, createTime: item.createTime})));
    
    total.value = response.total;

    creatorId.value = dangerHandleList.value.map((row) => row.creatorId);
    await queryUsersForIds(creatorId.value);
    loading.value = false;
  } catch (error) {
    console.error("获取隐患处理列表失败:", error);
    loading.value = false;
  }
}

async function queryUsersForIds(ids) {
  // 过滤掉无效的ID（null、undefined、非数字值）
  const validIds = ids.filter(id => id != null && id !== undefined && !isNaN(id));
  if (validIds.length === 0) {
    return;
  }
  
  // 去重，避免重复请求
  const uniqueIds = [...new Set(validIds)];
  
  const promises = uniqueIds.map(async (id) => {
    try {
      const response = await getUser(id);
      handleSingleUserResponse(response.data, id);
    } catch (error) {
      console.error(`获取用户信息失败 (id: ${id}):`, error);
      // 继续执行其他请求，不中断
    }
  });

  await Promise.all(promises).catch((errors) =>
    console.error("部分请求失败:", errors)
  );
}
function handleSingleUserResponse(data, creatorIdItem) {
  if (data && data.userName) {
    dangerHandleList.value.forEach((task) => {
      if (task.creatorId === creatorIdItem) {
        task.userName = data.nickName;
      }
    });
  }
}
// 取消按钮
function addcancel() {
  reset();
  addopen.value = false;
}
function editcancel() {
  reset();
  editopen.value = false;
}
function morecancel() {
  dangermoreopen.value = false;
  handleresultopen.value = false;
}
// 表单重置
function reset() {
  addform.value = {
    id: null,
    troubleTitle: null,
    creatorId: null,
    troubleImgPath: null,
    troubleDesc: null,
    status: null,
    troubleClassify: null,
    source: null,
    handlerId: null,
    handleImgPath: null,
    rectifyDesc: null,
    rectifyTime: null,
    createTime: null,
    updateTime: null,
    remark: null,
  };
  addfileList.value = [];
  editform.value = {
    id: null,
    troubleTitle: null,
    creatorId: null,
    troubleImgPath: null,
    troubleDesc: null,
    status: null,
    troubleClassify: null,
    source: null,
    handlerId: null,
    handleImgPath: null,
    rectifyDesc: null,
    rectifyTime: null,
    createTime: null,
    updateTime: null,
    remark: null,
  };
  editfileList.value = [];
  proxy.resetForm("dangerHandleRef");
}

/** 查询按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// 多选框选中数据
function handleSelectionChange(selection) {
  ids.value = selection.map((item) => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 新增按钮操作 */
function handleAdd() {
  reset();
  listUser({ pageSize: 1000 }).then((response) => {
    response.rows.forEach((item) => {
      creator.value.push(item.nickName);
    });
  });
  addopen.value = true;
}

/** 编辑按钮操作 */
function handleUpdate(row) {
  reset();
  const _id = row.id || ids.value;
  getDangerHandle(_id).then((response) => {
    editform.value = response.data;
    if (response.data.troubleImgPath) {
      editform.value.troubleImgPath = response.data.troubleImgPath.split(",");
      editfileList.value = editform.value.troubleImgPath.map((url, index) => {
        return {
          name: `${url.split("/").pop()}`, // 提取文件名
          url: url, // 文件URL
        };
      });
    }
    if (editform.value.creatorId != null && editform.value.creatorId !== undefined && !isNaN(editform.value.creatorId)) {
      getUser(editform.value.creatorId).then((response) => {
        editform.value.createBy = response.data.nickName;
      }).catch((error) => {
        console.error("获取用户信息失败:", error);
      });
    }
    editopen.value = true;
  });
}
// 查看详情按钮操作
function handleDangerMore(row) {
  const _id = row.id || ids.value;
  getDangerHandle(_id).then((response) => {
    dangermoreform.value = response.data;
    troubleImgPaths.value = response.data.troubleImgPath.split(",");
    if (dangermoreform.value.creatorId != null && dangermoreform.value.creatorId !== undefined && !isNaN(dangermoreform.value.creatorId)) {
      getUser(dangermoreform.value.creatorId).then((response) => {
        creatorUserName.value = response.data.nickName;
      }).catch((error) => {
        console.error("获取用户信息失败:", error);
      });
    }
    dangermoreopen.value = true;
  });
}
// 处理结果按钮操作
function handleDangerHandleResult(row) {
  const _id = row.id || ids.value;
  getDangerHandle(_id).then((response) => {
    handleresultform.value = response.data;
    handleImgPaths.value = response.data.handleImgPath.split(",");
    if (handleresultform.value.handlerId != null && handleresultform.value.handlerId !== undefined && !isNaN(handleresultform.value.handlerId)) {
      getUser(handleresultform.value.handlerId).then((response) => {
        handlerIdUserName.value = response.data.nickName;
      }).catch((error) => {
        console.error("获取用户信息失败:", error);
      });
    }
    handleresultopen.value = true;
  });
}
/** 提交按钮 */
function editsubmitForm() {
  updateDangerHandle(editform.value).then((response) => {
    proxy.$modal.msgSuccess("编辑成功");
    editopen.value = false;
    getList();
  });
}
function addsubmitForm() {
  addDangerHandle(addform.value).then((response) => {
    proxy.$modal.msgSuccess("新增成功");
    addopen.value = false;
    getList();
  });
}

/** 删除按钮操作 */
function handleDelete(row) {
  const _ids = row.id || ids.value;
  proxy.$modal
    .confirm('是否确认删除隐患编号为"' + _ids + '"的数据项？')
    .then(function () {
      return delDangerHandle(_ids);
    })
    .then(() => {
      getList();
      proxy.$modal.msgSuccess("删除成功");
    })
    .catch(() => {});
}

/** 导出按钮操作 */
function handleExport() {
  proxy.download(
    "danger/dangerHandle/export",
    {
      ...queryParams.value,
    },
    `dangerHandle_${new Date().getTime()}.xlsx`
  );
}

getList();
const getHandleStatusStyles = (status) => {
  switch (status) {
    case 0:
      return {
        color: "#ff1a04",
        textShadow: "0px 0px 0.3px #ff1a04",
      };
    case 1:
      return {
        color: "#06c08b",
        textShadow: "0px 0px 0.3px #06c08b",
      };
    default:
      return {};
  }
};

const tagStyle = computed(() => {
  switch (dangermoreform.value.status) {
    case 0:
      return {
        backgroundColor: "#ff1a0422",
        color: "#ff1a04",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #ff1a04",
        fontSize: "13.5px",
      };
    case 1:
      return {
        backgroundColor: "#06c08b22",
        color: "#06c08b",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #06c08b",
        fontSize: "13.5px",
      };
  }
});

const statusText = computed(() => {
  switch (dangermoreform.value.status) {
    case 0:
      return "未处理";
    case 1:
      return "已处理";
    default:
      return "未知状态";
  }
});
const troubleClassifyText = computed(() => {
  switch (dangermoreform.value.troubleClassify) {
    case 0:
      return "地质隐患";
    case 1:
      return "设备隐患";
    case 2:
      return "环境隐患";
    case 3:
      return "生产隐患";
    case 4:
      return "其他";
    default:
      return "未知";
  }
});
const sourceText = computed(() => {
  switch (dangermoreform.value.source) {
    case 0:
      return "随手拍";
    case 1:
      return "上传";
    default:
      return "未知来源";
  }
});
</script>
