<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      ref="queryRef"
      :inline="true"
      v-show="showSearch"
      label-width="80px"
    >
      <el-form-item label="问题标题" prop="questionTitle">
        <el-input
          v-model="queryParams.questionTitle"
          placeholder="请输入问题标题"
          clearable
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="上传日期" prop="createTime">
        <el-date-picker
          clearable
          v-model="queryParams.createTime"
          type="date"
          value-format="YYYY-MM-DD"
          placeholder="请选择上传日期"
        >
        </el-date-picker>
      </el-form-item>
      <el-form-item label="审核状态" prop="property">
        <el-select
          v-model="queryParams.property"
          placeholder="请选择事件定性"
          clearable
          style="width: 220px"
        >
          <el-option
            v-for="dict in snapshot_property"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          icon="Search"
          color="#03bd8a"
          @click="handleQuery"
          style="text-shadow: 0 0 0.3px #fff"
          >查询</el-button
        >
        <el-button
          icon="Refresh"
          @click="resetQuery"
          style="text-shadow: 0 0 0.3px #606266"
          >重置</el-button
        >
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <right-toolbar
        v-model:showSearch="showSearch"
        @queryTable="getList"
      ></right-toolbar>
    </el-row>

    <el-table
      v-loading="loading"
      :data="snapshotExamineList"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="30" align="center" />
      <el-table-column label="序号" width="60" align="center" type="index"/>
      <el-table-column
        label="问题标题"
        width="250"
        align="center"
        prop="questionTitle"
      />
      <el-table-column
        label="上传人"
        width="160"
        align="center"
        prop="nickName"
      />
      <el-table-column
        label="上传时间"
        align="center"
        prop="createTime"
        width="150"
      >
        <template #default="scope">
          <span>{{ parseTime(scope.row.createTime, "{y}-{m}-{d}") }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="事件状态"
        width="150"
        align="center"
        prop="property"
      >
        <template #default="scope">
          <dict-tag
            :options="snapshot_property"
            :value="scope.row.property"
            :style="getpropertyStyles(scope.row.property)"
          />
        </template>
      </el-table-column>
      <el-table-column label="备注" width="300" align="center" prop="remark" />
      <el-table-column
        label="随手拍详情"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            class="moreButton"
            color="#3b87e0"
            plain
            @click="handleSnapshotMore(scope.row)"
            v-hasPermi="['snapshot:snapshotExamine:snapshotmore']"
            >查看详情</el-button
          >
        </template>
      </el-table-column>
      <el-table-column
        label="操作"
        width="180"
        align="center"
        class-name="small-padding fixed-width"
      >
        <template #default="scope">
          <el-button
            type="primary"
            class="auditButton"
            plain
            @click="handleUpdate(scope.row)"
            v-hasPermi="['snapshot:snapshotExamine:edit']"
            >审批</el-button
          >
          <el-button
            class="DelButton"
            color="#ff7b47"
            plain
            @click="handleDelete(scope.row)"
            v-hasPermi="['snapshot:snapshotExamine:remove']"
            >删除</el-button
          >
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />
    <!-- 随手拍详情对话框 -->
    <el-dialog
      title="随手拍详情"
      v-model="snapshotmoreopen"
      width="800px"
      append-to-body
    >
      <span class="Basic">| <span class="Mes">详细信息</span></span>
      <el-descriptions border column="2">
        <el-descriptions-item :span="2" label="问题标题">{{
          snapshotmoreform.questionTitle
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="问题图片"
          ><el-image
            v-for="(url, index) in imgPaths"
            :key="index"
            :src="url"
            :preview-src-list="imgPaths"
            style="
              width: auto;
              height: auto;
              margin-right: 10px;
              display: inline-block;
            "
        /></el-descriptions-item>
        <el-descriptions-item :span="2" label="问题描述">{{
          snapshotmoreform.questionDesc
        }}</el-descriptions-item>
        <el-descriptions-item label="上传人">{{
          creatorUserName
        }}</el-descriptions-item>
        <el-descriptions-item label="上传时间">{{
          snapshotmoreform.createTime
        }}</el-descriptions-item>
        <el-descriptions-item label="审批人">{{
          handlerIdUserName
        }}</el-descriptions-item>
        <el-descriptions-item label="事件定性"
          ><el-tag size="small" :style="tagStyle" effect="dark">{{
            propertyText
          }}</el-tag>
        </el-descriptions-item>
        <el-descriptions-item :span="2" label="审批回复">{{
          snapshotmoreform.approvalReply
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="修改时间">{{
          snapshotmoreform.updateTime
        }}</el-descriptions-item>
        <el-descriptions-item :span="2" label="备注">{{
          snapshotmoreform.remark
        }}</el-descriptions-item>
      </el-descriptions>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="morecancel">确 定</el-button>
          <el-button @click="morecancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
    <!-- 审批随手拍对话框 -->
    <el-dialog
      title="审核随手拍"
      v-model="examineopen"
      width="600px"
      append-to-body
    >
      <span class="Basic">| <span class="Mes">基本信息</span></span>
      <el-form
        ref="snapshotExamineRef"
        :model="examineform"
        :rules="rules"
        label-width="100px"
        style="margin-top: 20px"
      >
        <el-form-item label="问题标题" prop="questionTitle">
          <el-input
            v-model="examineform.questionTitle"
            placeholder="请输入问题标题"
          />
        </el-form-item>
        <el-form-item label="事件定性" prop="property">
          <el-radio-group v-model="examineform.property">
            <el-radio
              v-for="dict in snapshot_property"
              :key="dict.value"
              :label="parseInt(dict.value)"
              >{{ dict.label }}</el-radio
            >
          </el-radio-group>
        </el-form-item>
        <el-form-item label="审批回复" prop="approvalReply">
          <el-input
            v-model="examineform.approvalReply"
            placeholder="请输入审批回复"
            type="textarea"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submitForm">确 定</el-button>
          <el-button @click="examinecancel">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>
  
  <script setup name="SnapshotExamine">
import {
  listSnapshotExamine,
  getSnapshotExamine,
  delSnapshotExamine,
  updateSnapshotExamine,
  getUser,
} from "@/api/snapshot/snapshotExamine";

const { proxy } = getCurrentInstance();
const { snapshot_property } = proxy.useDict("snapshot_property");

const snapshotExamineList = ref([]);
const creatorId = ref([]);

const creatorUserName = ref('');
const handlerIdUserName = ref('');

const snapshotmoreopen = ref(false);
const examineopen = ref(false);

const imgPaths = ref([]);

const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);

const data = reactive({
  examineform: {},
  snapshotmoreform: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    questionTitle: null,
    property: null,
    createTime: null,
  },
  rules: {
    questionTitle: [
      { required: true, message: "问题标题不能为空", trigger: "blur" },
    ],
    creatorId: [{ required: true, message: "上传人不能为空", trigger: "blur" }],
  },
});

const { queryParams, examineform, snapshotmoreform, rules } = toRefs(data);

/** 查询随手拍问题列表 */
async function getList() {
  loading.value = true;
  try {
    const response = await listSnapshotExamine(queryParams.value);
    snapshotExamineList.value = response.rows;
    total.value = response.total;

    creatorId.value = response.rows.map((row) => row.creatorId);
    await queryUsersForIds(creatorId.value);

    loading.value = false;
  } catch (error) {
    console.error("获取任务列表失败:", error);
    loading.value = false;
  }
}
async function queryUsersForIds(ids) {
  const promises = ids.map(async (id) => {
    const response = await getUser(id);
    handleSingleUserResponse(response.data, id);
  });

  await Promise.all(promises).catch((errors) =>
    console.error("部分请求失败:", errors)
  );
}
function handleSingleUserResponse(data, creatorIdItem) {
  if (data && data.nickName) {
    // const existingRiskIndex = usersName.value.findIndex(
    //   (item) => item.creatorId === creatorIdItem
    // );
    // if (existingRiskIndex === -1) {
    //   usersName.value.push({
    //     creatorId: creatorIdItem,
    //     userName: data.userName,
    //   });
    // } else {
    //   usersName.value[existingRiskIndex].userName = data.userName;
    // }
    snapshotExamineList.value.forEach((task) => {
      if (task.creatorId === creatorIdItem) {
        task.nickName = data.nickName;
      }
    });
  }
}
// 取消按钮
function morecancel() {
  snapshotmoreopen.value = false;
}
function examinecancel() {
  examineopen.value = false;
  reset();
}
// 表单重置
function reset() {
  examineform.value = {
    id: null,
    questionTitle: null,
    questionDesc: null,
    creatorId: null,
    imgPath: null,
    handlerId: null,
    approvalReply: null,
    property: null,
    handlerTime: null,
    createTime: null,
    updateTime: null,
    remark: null,
  };
  proxy.resetForm("snapshotExamineRef");
}

/** 查询按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}

/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

// 多选框选中数据
function handleSelectionChange(selection) {
  ids.value = selection.map((item) => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}

/** 审批按钮操作 */
function handleUpdate(row) {
  reset();
  const _id = row.id || ids.value;
  getSnapshotExamine(_id).then((response) => {
    examineform.value = response.data;
    examineopen.value = true;
  });
}
// 查看详情按钮操作
function handleSnapshotMore(row) {
  const _id = row.id || ids.value;
  getSnapshotExamine(_id).then((response) => {
    snapshotmoreform.value = response.data;
    imgPaths.value = response.data.imgPath.split(",");
    getUser(snapshotmoreform.value.creatorId).then((response) => {
      creatorUserName.value = response.data.nickName;
      getUser(snapshotmoreform.value.handlerId).then((response) => {
        handlerIdUserName.value = response.data.nickName;
      });
    });
    snapshotmoreopen.value = true;
  });
}
/** 提交按钮 */
function submitForm() {
  proxy.$refs["snapshotExamineRef"].validate((valid) => {
    if (valid) {
      if (examineform.value.id != null) {
        updateSnapshotExamine(examineform.value).then((response) => {
          proxy.$modal.msgSuccess("审批成功");
          examineopen.value = false;
          getList();
        });
      }
    }
  });
}

/** 删除按钮操作 */
function handleDelete(row) {
  const _ids = row.id || ids.value;
  proxy.$modal
    .confirm('是否确认删除随手拍编号为"' + _ids + '"的数据项？')
    .then(function () {
      return delSnapshotExamine(_ids);
    })
    .then(() => {
      getList();
      proxy.$modal.msgSuccess("删除成功");
    })
    .catch(() => {});
}

getList();
const getpropertyStyles = (status) => {
  switch (status) {
    case 0:
      return {
        color: "#fb9a29",
        textShadow: "0px 0px 0.3px #fb9a29",
      };
    case 1:
      return {
        color: "#ff1a04",
        textShadow: "0px 0px 0.3px #ff1a04",
      };
    case 2:
      return {
        color: "#06c08b",
        textShadow: "0px 0px 0.3px #06c08b",
      };
    default:
      return {};
  }
};
const tagStyle = computed(() => {
  switch (snapshotmoreform.value.property) {
    case 0:
      return {
        backgroundColor: "#fb9a2922",
        color: "#fb9a29",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #fb9a29",
        fontSize: "13.5px",
      };
    case 1:
      return {
        backgroundColor: "#ff1a0422",
        color: "#ff1a04",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #ff1a04",
        fontSize: "13.5px",
      };
    case 2:
      return {
        backgroundColor: "#06c08b22",
        color: "#06c08b",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #06c08b",
        fontSize: "13.5px",
      };
  }
});

const propertyText = computed(() => {
  switch (snapshotmoreform.value.property) {
    case 0:
      return "未审核";
    case 1:
      return "隐患";
    case 2:
      return "非隐患";
    default:
      return "未知状态";
  }
});
</script>
  