<template>
  <div class="indexHtml" ref="echartsBox">
    <div class="left">
      <div class="leftTop">
        <div class="todayWork">
          <div class="todayWorkTitle">
            <span class="TitleLeft">今日待办</span>
            <a href="./work/audit/"><p class="TitleRight">查看更多数据 ></p></a>
          </div>
          <div class="todayWorkMain">
            <div class="todayWorkMainBox">
              <span class="BoxTop">作业审批</span>
              <span class="BoxMid">{{ workaudit }}</span>
              <a href="./work/audit/"
                ><el-button type="primary" plain color="#3483de"
                  >去处理</el-button
                ></a
              >
            </div>
            <div class="todayWorkMainBox">
              <span class="BoxTop">随手拍审批</span>
              <span class="BoxMid">{{ snapshotExamine }}</span>
              <a href="./snapshot/snapshotExamine/"
                ><el-button type="primary" plain color="#3483de"
                  >去处理</el-button
                ></a
              >
            </div>
            <!-- <div class="todayWorkMainBox">
              <span class="BoxTop">巡查项</span>
              <span class="BoxMid">25</span>
              <a href=""
                ><el-button type="primary" plain color="#3483de"
                  >去处理</el-button
                ></a
              >
            </div> -->
            <div class="todayWorkMainBox">
              <span class="BoxTop">巡查清单</span>
              <span class="BoxMid">{{ patrolRecord }}</span>
              <a href="./patrol/patrolRecord/"
                ><el-button type="primary" plain color="#3483de"
                  >去查看</el-button
                ></a
              >
            </div>
            <div class="todayWorkMainBox">
              <span class="BoxTop">隐患处理</span>
              <span class="BoxMid">{{ dangerHandle }}</span>
              <a href="./danger/dangerHandle/"
                ><el-button type="primary" plain color="#3483de"
                  >去处理</el-button
                ></a
              >
            </div>
          </div>
        </div>
        <div class="riskItemStatistic">
          <riskItemStatistic></riskItemStatistic>
        </div>

      </div>
      <div class="leftBottom">
        <div class="leftBottomBox">
          <img src="../assets/images/indexHtml/总人数.png" alt="" />
          <span class="leftBottomBoxTitle">总人数</span>
          <span class="leftBottomBoxNum">{{ userNum }}</span>
          <span class="leftBottomBoxRate"
            >+35%{{ x }}<span class="ThisMonth"> This Month</span></span
          >
        </div>
        <div class="leftBottomBox">
          <img src="../assets/images/indexHtml/高风险库.png" alt="" />
          <span class="leftBottomBoxTitle">风险库</span>
          <span class="leftBottomBoxNum">{{ riskNum }}</span>
          <span class="leftBottomBoxRate"
            >+35%{{ x }}<span class="ThisMonth"> This Month</span></span
          >
        </div>
        <div class="leftBottomBox">
          <img src="../assets/images/indexHtml/风险项目.png" alt="" />
          <span class="leftBottomBoxTitle">风险项</span>
          <span class="leftBottomBoxNum">{{ unverifiedRiskNum }}</span>
          <span class="leftBottomBoxRate"
            >+35%{{ x }}<span class="ThisMonth"> This Month</span></span
          >
        </div>
        <div class="leftBottomBox" style="margin-right: 0px">
          <img src="../assets/images/indexHtml/巡查点位.png" alt="" />
          <span class="leftBottomBoxTitle">巡查点</span>
          <span class="leftBottomBoxNum">{{ pointNum }}</span>
          <span class="leftBottomBoxRate"
            >+35%{{ x }}<span class="ThisMonth"> This Month</span></span
          >
        </div>
      </div>
    </div>
    <div class="right">
      <div class="snapshot">
        <div class="snapshotTitle">
          <span class="TitleLeft">随手拍通知</span>
          <a href="./snapshot/snapshotExamine/"
            ><p class="TitleRight">查看更多 ></p></a
          >
        </div>
        <div class="snapshotMain">
          <el-scrollbar>
            <li v-for="mes in snapshot" :key="mes.id">
              <div class="snapshotBox">
                <div class="snapshotPosition" :style="tagStyle(mes.property)">
                  <span>{{ propertyText(mes.property) }}</span>
                </div>
                <div class="snapshotMes">
                  <span class="MesDetail">{{ mes.questionDesc }}</span>
                  <span class="MesTime">{{ mes.createTime }}</span>
                </div>
              </div>
            </li>
          </el-scrollbar>
        </div>
      </div>
      <div class="dangerMes">
        <div class="dangerMesTitle">
          <span class="TitleLeft">隐患消息</span>
          <a href="./danger/dangerHandle/"
            ><p class="TitleRight">查看更多 ></p></a
          >
        </div>
        <div class="dangerMesMain">
          <el-scrollbar>
            <li v-for="danger in dangerMes" :key="danger.id">
              <div class="leftLi">
                <div class="dangerMesImg">
                  <img src="../assets/images/indexHtml/小圆点.png" alt="" />
                </div>
                <div class="dangerMesBox">
                  <span class="dangerMesDetail">{{ danger.troubleDesc }}</span>
                  <div class="dangerMesPs">
                    <span class="dangerMesTime">{{ danger.createTime }}</span>
                    <a href="./danger/dangerHandle/"
                      ><span class="dangerMesMore">查看详情</span></a
                    >
                  </div>
                </div>
              </div>
            </li>
          </el-scrollbar>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import riskItemStatistic from "@/components/echarts/indexHtml/riskItemStatistic.vue";
import { listTask } from "@/api/work/fill";
import { listSnapshotExamine } from "@/api/snapshot/snapshotExamine";
import { listpatrolRecord } from "@/api/patrol/patrolRecord";
import { listDangerHandle } from "@/api/danger/dangerHandle";
import { listUser } from "@/api/system/user";
import { listRiskLibrary } from "@/api/risk/riskLibrary";
import { listRiskPend } from "@/api/risk/riskPend";
import { listPatrolPoint } from "@/api/patrol/patrolPoint";
// 作业审核数量
const workaudit = ref();
const queryParamsworkaudit = ref({
  approvalStatus: 0,
});
async function getworkaudit() {
  const response = await listTask(queryParamsworkaudit.value);
  workaudit.value = response.total;
}
getworkaudit();
// 随手拍审批数量
// 随手拍通知
const snapshotExamine = ref();
const snapshot = ref([]);
const queryParamssnapshotExamine = ref({
  property: 0,
});
async function getsnapshotExamine() {
  const response = await listSnapshotExamine(queryParamssnapshotExamine.value);
  snapshotExamine.value = response.total;
  snapshot.value = response.rows;
}
getsnapshotExamine();
// 巡查清单数
const patrolRecord = ref();
const queryParamspatrolRecord = ref({});
async function getpatrolRecord() {
  const response = await listpatrolRecord(queryParamspatrolRecord.value);
  patrolRecord.value = response.total;
}
getpatrolRecord();
// 隐患处理数量
const dangerHandle = ref();
const dangerMes = ref([]);
const queryParamsdangerHandle = ref({
  status: 0,
});
async function getdangerHandle() {
  const response = await listDangerHandle(queryParamsdangerHandle.value);
  dangerHandle.value = response.total;
  dangerMes.value = response.rows;
}
getdangerHandle();
// 总人数
const userNum = ref();
const queryParamsuserNum = ref({});
async function getuserNum() {
  const response = await listUser(queryParamsuserNum.value);
  userNum.value = response.total;
}
getuserNum();
// 风险库总数
const riskNum = ref();
const queryParamsriskNum = ref({});
async function getriskNum() {
  const response = await listRiskLibrary(queryParamsriskNum.value);
  riskNum.value = response.total;
}
getriskNum();
// 风险项总数
const unverifiedRiskNum = ref();
const queryParamsunverifiedRiskNum = ref({});
async function getunverifiedRiskNum() {
  const response = await listRiskPend(queryParamsunverifiedRiskNum.value);
  unverifiedRiskNum.value = response.total;
}
getunverifiedRiskNum();
// 巡查点总数
const pointNum = ref();
const queryParamspointNum = ref({});
async function getpointNum() {
  const response = await listPatrolPoint(queryParamspointNum.value);
  pointNum.value = response.total;
}
getpointNum();

const tagStyle = (property) => {
  switch (property) {
    case 0:
      return {
        backgroundColor: "#fb9a2922",
        color: "#fb9a29",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #fb9a29",
        fontSize: "13.5px",
      };
    case 1:
      return {
        backgroundColor: "#ff1a0422",
        color: "#ff1a04",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #ff1a04",
        fontSize: "13.5px",
      };
    case 2:
      return {
        backgroundColor: "#06c08b22",
        color: "#06c08b",
        borderColor: "#fff",
        textShadow: "0px 0px 0.3px #06c08b",
        fontSize: "13.5px",
      };
  }
};

const propertyText = (property) => {
  switch (property) {
    case 0:
      return "未审核";
    case 1:
      return "隐患";
    case 2:
      return "非隐患";
    default:
      return "未知状态";
  }
};
</script>

<style scoped lang="scss">
@import "../assets/styles/indexHtml/indexHtml.scss";
</style>