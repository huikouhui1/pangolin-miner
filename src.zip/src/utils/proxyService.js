/**
 * 用于处理跨域请求的代理服务工具
 * 
 * 注意: 跨域嵌入限制是浏览器的安全机制，前端无法完全绕过
 * 要解决跨域访问问题，需要：
 * 1. 使用后端代理服务器转发请求 
 * 2. 目标服务器设置允许跨域访问的响应头
 */

import axios from 'axios';

// 配置后端代理地址 (需要后端开发人员提供)
const PROXY_BASE_URL = '/api/proxy';

/**
 * 通过后端代理请求外部资源
 * @param {string} url 要请求的目标URL
 * @param {Object} options 请求选项
 * @returns {Promise} 返回请求结果
 */
export const fetchViaProxy = async (url, options = {}) => {
  try {
    const response = await axios({
      url: `${PROXY_BASE_URL}`,
      method: 'post',
      data: {
        targetUrl: url,
        ...options
      }
    });
    return response.data;
  } catch (error) {
    console.error('Proxy request failed:', error);
    throw error;
  }
};

/**
 * 打开URL在新窗口
 * @param {string} url 目标URL
 * @param {Object} options 窗口选项
 */
export const openInNewWindow = (url, options = {}) => {
  const defaultOptions = {
    noopener: true,
    noreferrer: true,
    ...options
  };
  
  const windowFeatures = Object.entries(defaultOptions)
    .filter(([key]) => key !== 'noopener' && key !== 'noreferrer')
    .map(([key, value]) => `${key}=${value}`)
    .join(',');
  
  const windowName = '_blank';
  const windowFeatureString = windowFeatures ? windowFeatures : 'noopener,noreferrer';
  
  window.open(url, windowName, windowFeatureString);
};

/**
 * 后端代理要实现的步骤说明
 * 可以作为提示信息显示给系统管理员
 */
export const getProxyImplementationSteps = () => {
  return [
    "1. 在后端服务中设置一个代理路由，例如 '/api/proxy'",
    "2. 在这个路由处理器中，获取目标URL并使用服务器端HTTP客户端发送请求",
    "3. 将响应的内容、状态码和头信息从目标服务器转发到前端",
    "4. 确保设置正确的CORS头，允许前端访问",
    "5. 对于HTML内容，可能需要重写内部链接和资源引用"
  ];
};
