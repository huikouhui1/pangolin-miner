/**
 * 地图内容缓存服务
 * 用于管理地图内容的缓存，提供离线访问能力
 */

// 缓存名称和版本
const MAP_CACHE_NAME = 'clb-map-cache-v1';
// 缓存有效期（毫秒）: 7天
const CACHE_TTL = 7 * 24 * 60 * 60 * 1000;
// 缓存元数据键
const CACHE_META_KEY = 'clb-map-cache-meta';

/**
 * 缓存地图内容
 * @param {string} url 地图URL
 * @returns {Promise<Object>} 缓存元数据
 */
export const cacheMapContent = async (url) => {
  // 确保移除URL中可能的缓存标记
  const cleanUrl = url.replace(/(&cached=true|&forceCache=true)/g, '');
  
  try {
    // 仅在支持Service Worker和Cache API的环境下执行
    if ('caches' in window) {
      const cache = await caches.open(MAP_CACHE_NAME);
      
      // 1. 尝试获取页面内容
      const response = await fetch(cleanUrl, { 
        mode: 'no-cors' // 使用no-cors模式来避免CORS问题，但会限制响应的使用方式
      });
      
      // 2. 将响应缓存
      if (response) {
        await cache.put(cleanUrl, response);
      }
      
      // 3. 保存缓存元数据
      const metadata = {
        url: cleanUrl,
        timestamp: Date.now(),
        status: 'valid'
      };
      
      localStorage.setItem(CACHE_META_KEY, JSON.stringify(metadata));
      
      return metadata;
    }
  } catch (error) {
    console.error('地图缓存失败:', error);
    throw error;
  }
  
  return null;
};

/**
 * 获取缓存的地图信息
 * @returns {Promise<Object|null>} 缓存信息
 */
export const getCachedMapInfo = async () => {
  try {
    const metadataStr = localStorage.getItem(CACHE_META_KEY);
    if (!metadataStr) {
      return { status: 'empty' };
    }
    
    const metadata = JSON.parse(metadataStr);
    const now = Date.now();
    
    // 检查缓存是否过期
    if (now - metadata.timestamp > CACHE_TTL) {
      metadata.status = 'outdated';
    }
    
    // 检查缓存条目是否存在
    if ('caches' in window) {
      const cache = await caches.open(MAP_CACHE_NAME);
      const response = await cache.match(metadata.url);
      if (!response) {
        metadata.status = 'empty';
      }
    }
    
    return metadata;
  } catch (error) {
    console.error('获取缓存信息失败:', error);
    return { status: 'error', error: error.message };
  }
};

/**
 * 清除地图缓存
 * @returns {Promise<boolean>} 操作是否成功
 */
export const clearCache = async () => {
  try {
    // 删除缓存元数据
    localStorage.removeItem(CACHE_META_KEY);
    
    // 清除Cache API中的缓存
    if ('caches' in window) {
      await caches.delete(MAP_CACHE_NAME);
    }
    
    return true;
  } catch (error) {
    console.error('清除缓存失败:', error);
    return false;
  }
};
