import request from '@/utils/request'

// 查询巡查点管理列表
export function listPatrolPoint(query) {
  return request({
    url: '/rsm/patrol/point/list',
    method: 'get',
    params: query
  })
}

// 查询巡查点管理详细
export function getPatrolPoint(id) {
  return request({
    url: '/rsm/patrol/point/' + id,
    method: 'get'
  })
}


// 新增巡查点管理
export function addPatrolPoint(data) {
  return request({
    url: '/rsm/patrol/point',
    method: 'post',
    data: data
  })
}

// 修改巡查点管理
export function updatePatrolPoint(data) {
  return request({
    url: '/rsm/patrol/point',
    method: 'put',
    data: data
  })
}

// 删除巡查点管理
export function delPatrolPoint(id) {
  return request({
    url: '/rsm/patrol/point/' + id,
    method: 'delete'
  })
}
