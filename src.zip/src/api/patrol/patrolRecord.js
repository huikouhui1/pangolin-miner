import request from '@/utils/request'
import { parseStrEmpty } from "@/utils/ruoyi";

// 查询巡查记录列表
export function listpatrolRecord(query) {
  return request({
    url: '/rsm/patrol/list/list',
    method: 'get',
    params: query
  })
}
// 删除风险库管理
export function delpatrolRecord(id) {
  return request({
    url: '/rsm/patrol/' + id,
    method: 'delete'
  })
}

// 查询用户详细
export function getUser(userId) {
  return request({
    url: '/system/user/' + parseStrEmpty(userId),
    method: 'get'
  })
}
