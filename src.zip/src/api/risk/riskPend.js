import request from '@/utils/request'

// 查询风险项管理列表
export function listRiskPend(query) {
  return request({
    url: '/rsm/unverified/risk/list',
    method: 'get',
    params: query
  })
}
export function listRiskPendAll(query) {
  return request({
    url: '/rsm/unverified/risk/all',
    method: 'get',
    params: query
  })
}
export function listRiskAll() {
  return request({
    url: '/rsm/risk/all',
    method: 'get',
  })
}
export function listPatrolPointAll() {
  return request({
    url: '/rsm/patrol/point/all',
    method: 'get',
  })
}
// 查询风险项管理详细
export function getRiskPend(id) {
  return request({
    url: '/rsm/unverified/risk/' + id,
    method: 'get'
  })
}

// 查询风险详细
export function getRiskLibrary(id) {
  return request({
    url: '/rsm/risk/' + id,
    method: 'get'
  })
}

// 新增风险项管理
export function addRiskPend(data) {
  return request({
    url: '/rsm/unverified/risk',
    method: 'post',
    data: data
  })
}

// 修改风险项管理
export function updateRiskPend(data) {
  return request({
    url: '/rsm/unverified/risk',
    method: 'put',
    data: data
  })
}

// 删除风险项管理
export function delRiskPend(id) {
  return request({
    url: '/rsm/unverified/risk/' + id,
    method: 'delete'
  })
}

// 获取巡查点详情
export function getPoint(id) {
  return request({
    url: '/rsm/patrol/point/' + id,
    method: 'get'
  })
}

// 最近12个月
export function get12() {
  return request({
    url: '/rsm/unverified/risk/countByMonth',
    method: 'get'
  })
}
// 最近30天
export function get30() {
  return request({
    url: '/rsm/unverified/risk/countByThisMonth',
    method: 'get'
  })
}