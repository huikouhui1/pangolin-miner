import request from '@/utils/request'

// 查询风险库管理列表
export function listRiskLibrary(query) {
  return request({
    url: '/rsm/risk/list',
    method: 'get',
    params: query
  })
}

// 查询风险库管理详细
export function getRiskLibrary(id) {
  return request({
    url: '/rsm/risk/' + id,
    method: 'get'
  })
}

// 新增风险库管理
export function addRiskLibrary(data) {
  return request({
    url: '/rsm/risk',
    method: 'post',
    data: data
  })
}

// 修改风险库管理
export function updateRiskLibrary(data) {
  return request({
    url: '/rsm/risk',
    method: 'put',
    data: data
  })
}

// 删除风险库管理
export function delRiskLibrary(id) {
  return request({
    url: '/rsm/risk/' + id,
    method: 'delete'
  })
}
