import request from '@/utils/request'
import { parseStrEmpty } from "@/utils/ruoyi";

// 查询隐患处理列表
export function listDangerHandle(query) {
  return request({
    url: '/rsm/trouble/list',
    method: 'get',
    params: query
  })
}

// 查询隐患处理详细
export function getDangerHandle(id) {
  return request({ 
    url: '/rsm/trouble/' + id,
    method: 'get'
  })
}

// 新增隐患处理
export function addDangerHandle(data) {
  return request({
    url: '/rsm/trouble',
    method: 'post',
    data: data
  })
}

// 修改隐患处理
export function updateDangerHandle(data) {
  return request({
    url: '/rsm/trouble',
    method: 'put',
    data: data
  })
}

// 删除隐患处理
export function delDangerHandle(id) {
  return request({
    url: '/rsm/trouble/' + id,
    method: 'delete'
  })
}
// 查询用户列表
export function listUser(query) {
  return request({
    url: '/system/user/list',
    method: 'get',
    params: query
  })
}
// 查询用户详细
export function getUser(userId) {
  return request({
    url: '/system/user/' + parseStrEmpty(userId),
    method: 'get'
  })
}
// 隐患图片上传
export function uploadImg(file) {
  return request({
    url: '/rsm/oss/upload',
    method: 'post',
    data:file,
  })
}
// 隐患图片删除
export function deleteImg(url) {
  return request({
    url: '/rsm/oss/delete',
    method: 'delete',
    data:url
  })
}
//隐患数量周变化
export function get7() {
  return request({
    url: '/rsm/trouble/countByWeek',
    method: 'get',
  })
}
//隐患数量年变化
export function get12() {
  return request({
    url: '/rsm/trouble/countByMonth',
    method: 'get',
  })
}
