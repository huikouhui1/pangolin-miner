import request from '@/utils/request'

// 查询作业审批列表
export function listAudit(query) {
  return request({
    url: '/rsm/task/list/riskLevel',
    method: 'get',
    params: query
  })
}

// 查询作业审批详细
export function getAudit(id) {
  return request({
    url: '/rsm/task/' + id,
    method: 'get'
  })
}

// 新增作业审批
export function addAudit(data) {
  return request({
    url: '/rsm/task',
    method: 'post',
    data: data
  })
}

// 修改作业审批
export function updateAudit(data) {
  return request({
    url: '/rsm/task',
    method: 'put',
    data: data
  })
}

// 查询风险库管理详细
export function getRiskLibrary(id) {
  return request({
    url: '/rsm/risk/' + id,
    method: 'get'
  })
}
// 查询巡查点详细
export function getPoint(id) {
  return request({
    url: '/rsm/patrol/point/' + id,
    method: 'get'
  })
}

