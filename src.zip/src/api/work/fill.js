import request from '@/utils/request'

// 查询作业填报列表
export function listTask(query) {
  return request({
    url: '/rsm/task/list',
    method: 'get',
    params: query
  })
}
export function listRiskAll() {
  return request({
    url: '/rsm/risk/all',
    method: 'get',
  })
}
export function listPatrolPointAll() {
  return request({
    url: '/rsm/patrol/point/all',
    method: 'get',
  })
}
// 查询作业填报详细
export function getTask(id) {
  return request({
    url: '/rsm/task/' + id,
    method: 'get'
  })
}

// 新增作业填报
export function addTask(data) {
  return request({
    url: '/rsm/task',
    method: 'post',
    data: data
  })
}
// 批量
export function addTaskExcel(data) {
  return request({
    url: '/rsm/task/import',
    method: 'post',
    data: data
  })
}
// 修改作业填报
export function updateTask(data) {
  return request({
    url: '/rsm/task',
    method: 'put',
    data: data
  })
}

// 删除作业填报
export function delTask(id) {
  return request({
    url: '/rsm/task/' + id,
    method: 'delete'
  })
}

// 查询风险库管理详细
export function getRiskLibrary(id) {
  return request({
    url: '/rsm/risk/' + id,
    method: 'get'
  })
}
// 查询巡查点详细
export function getPoint(id) {
  return request({
    url: '/rsm/patrol/point/' + id,
    method: 'get'
  })
}
