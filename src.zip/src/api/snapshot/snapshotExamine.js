import request from '@/utils/request'
import { parseStrEmpty } from "@/utils/ruoyi";

// 查询随手拍问题列表
export function listSnapshotExamine(query) {
  return request({
    url: '/rsm/snapshot/list',
    method: 'get',
    params: query
  })
}

// 查询随手拍问题详细
export function getSnapshotExamine(id) {
  return request({
    url: '/rsm/snapshot/' + id,
    method: 'get'
  })
}

// 新增随手拍问题
export function addSnapshotExamine(data) {
  return request({
    url: '/rsm/snapshot',
    method: 'post',
    data: data
  })
}

// 修改随手拍问题
export function updateSnapshotExamine(data) {
  return request({
    url: '/rsm/snapshot',
    method: 'put',
    data: data
  })
}

// 删除随手拍问题
export function delSnapshotExamine(id) {
  return request({
    url: '/rsm/snapshot/' + id,
    method: 'delete'
  })
}

// 查询用户详细
export function getUser(userId) {
    return request({
      url: '/system/user/' + parseStrEmpty(userId),
      method: 'get'
    })
  }