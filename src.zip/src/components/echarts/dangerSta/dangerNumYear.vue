<template>
  <div id="yearEcharts" style="width: 100%; height: 360px"></div>
</template>
  <script setup>
import { onMounted } from "vue";
import * as echarts from "echarts";
import { get12 } from "@/api/danger/dangerHandle";
const data1 = ref([]);
const last12Months = ref([]);
async function get() {
  try {
    const response12 = await get12();
    data1.value = last12Months.value.map((month) => {
      const monthData = response12.data.find((data) => data.date === month);
      return monthData ? monthData.count : 0;
    });
    console.log(data1.value);
    initChart();
  } catch (error) {
    console.error("Failed to fetch danger data:", error);
  }
}
function initChart() {
  var yearEcharts = document.getElementById("yearEcharts");
  if (yearEcharts) {
    var myChart = echarts.init(yearEcharts);
    const handleResize = () => {
      myChart.resize();
    };
    window.addEventListener("resize", handleResize);
    onUnmounted(() => {
      window.removeEventListener("resize", handleResize);
    });
    var option = {
      color: ["#c70000"],
      title: {
        text: "隐患数量年变化",
        textStyle: {
          fontSize: 18,
          fontWeight: 400,
          color: "#303438",
          textShadowColor: "#303438",
          textShadowOffsetX: 0,
          textShadowOffsetY: 0,
          textShadowBlur: 1.3,
        },
      },
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "cross",
          label: {
            backgroundColor: "#6a7985",
          },
        },
      },
      legend: {
        icon: "roundRect",
        itemGap: 25, // 图例项之间的间隙
        textStyle: {
          color: "#000", // 文字颜色
          fontSize: 15, // 文字大小
        },
        data: ["最近12个月"],
        selected: {},
        selectedMode: "single",
      },
      toolbox: {
        feature: {
          saveAsImage: {},
        },
        right: "2%",
      },
      grid: {
        left: "2%",
        right: "2%",
        bottom: "5%",
        containLabel: true,
      },
      xAxis: [
        {
          type: "category",
          boundaryGap: false,
          data: getMonthsInCurrentYear(),
          axisLabel: {
            interval: 0,
            rotate: 0,
            fontSize: 12.5, // 文字大小
          },
        },
      ],
      yAxis: [
        {
          type: "value",
          axisLabel: {
            fontSize: 12.5, // 文字大小
          },
        },
      ],
      series: [
        {
          name: "最近12个月",
          type: "line",
          smooth: true,
          lineStyle: {
            width: 3,
          },
          showSymbol: false,
          areaStyle: {
            opacity: 0.3,
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "#c70000",
              },
              {
                offset: 1,
                color: "#c7000069",
              },
            ]),
          },
          emphasis: {
            focus: "series",
          },
          data: data1.value,
        },
      ],
    };
    option && myChart.setOption(option);

    // 监听图例变化
    myChart.on("legendselectchanged", function (params) {
      var selected = params.selected;
      var newOption = {};

      if (selected["最近12个月"]) {
        // 获取当前年份的12个月作为X轴数据
        newOption.xAxis = [
          {
            type: "category",
            boundaryGap: false,
            data: getMonthsInCurrentYear(),
            axisLabel: {
              interval: 0,
              rotate: 0,
            },
          },
        ];
      }
      // 更新图表配置
      myChart.setOption(newOption);
    });
  }
}
function getMonthsInCurrentYear() {
  var months = [];
  var today = new Date();
  var year = today.getFullYear();
  for (var i = 1; i <= 12; i++) {
    months.push(year + "-" + (i < 10 ? "0" : "") + i);
  }

  last12Months.value = months;
  return months;
}
onMounted(() => {
  get();
  getMonthsInCurrentYear();
});
</script>
  <style lang="scss" scoped>
</style>