<template>
  <div id="cateEcharts" style="width: 100%; height: 340px"></div>
</template>
  
  <script setup>
import { onMounted, ref } from "vue";
import * as echarts from "echarts";
import { listDangerHandle } from "@/api/danger/dangerHandle";

// 定义状态变量
const dangerData = ref([]);

// 查询条件
const queryParams0 = ref({ troubleClassify: 0 }); // 地质隐患
const queryParams1 = ref({ troubleClassify: 1 }); // 设备隐患
const queryParams2 = ref({ troubleClassify: 2 }); // 环境隐患
const queryParams3 = ref({ troubleClassify: 3 }); // 生产隐患
const queryParams4 = ref({ troubleClassify: 4 }); // 其他

// 获取所有隐患数据
async function get0() {
  try {
    // 发起多个请求，并等待所有请求完成
    const responses = await Promise.all([
      listDangerHandle(queryParams0.value),
      listDangerHandle(queryParams1.value),
      listDangerHandle(queryParams2.value),
      listDangerHandle(queryParams3.value),
      listDangerHandle(queryParams4.value),
    ]);

    // 处理每个响应
    responses.forEach((response, index) => {
      const total = response.total;
      const name = ["地质隐患", "设备隐患", "环境隐患", "生产隐患", "其他"][
        index
      ];
      dangerData.value.push({ name, value: total });
    });

    // 初始化图表
    initChart();
  } catch (error) {
    console.error("Failed to fetch danger data:", error);
  }
}

// 初始化图表
function initChart() {
  const cateEcharts = document.getElementById("cateEcharts");
  if (cateEcharts) {
    const myChart = echarts.init(cateEcharts);
    const handleResize = () => {
      myChart.resize();
    };
    window.addEventListener("resize", handleResize);
    onUnmounted(() => {
      window.removeEventListener("resize", handleResize);
    });
    const option = {
      tooltip: {
        trigger: "item",
      },
      title: {
        text: "隐患分类",
        textStyle: {
          fontSize: 18,
          fontWeight: 400,
          color: "#303438",
          textShadowColor: "#303438",
          textShadowOffsetX: 0,
          textShadowOffsetY: 0,
          textShadowBlur: 1.3,
        },
      },
      legend: {
        top: "bottom",
        textStyle: {
          fontSize: 14,
        },
      },
      toolbox: {
        show: true,
        feature: {
          mark: { show: true },
          dataView: { show: true, readOnly: false },
          restore: { show: true },
          saveAsImage: { show: true },
        },
      },
      series: [
        {
          name: "隐患种类",
          type: "pie",
          radius: [31, 155],
          center: ["50%", "50%"],
          roseType: "area",
          itemStyle: {
            borderRadius: 8,
          },
          label: {
            show: false,
            position: "center",
          },
          emphasis: {
            label: {
              show: true,
              fontSize: 14,
              fontWeight: "bold",
            },
          },
          labelLine: {
            show: false,
          },
          data: dangerData.value,
        },
      ],
    };
    option && myChart.setOption(option);
  }
}

// 初始化时获取数据并初始化图表
onMounted(() => {
  get0();
});
</script>
  
  <style lang="scss" scoped>
</style>