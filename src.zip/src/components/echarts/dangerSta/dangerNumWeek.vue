<template>
  <div id="weekEcharts" style="width: 100%; height: 340px"></div>
</template>

<script setup>
import { onMounted, onUnmounted, ref, nextTick } from "vue";
import * as echarts from "echarts";
import { get7 } from "@/api/danger/dangerHandle";

const data2 = ref([]);
const sevendays = ref([]);

async function get() {
  try {
    const response7 = await get7();
    const rawData = response7.data;

    // 🧡 1. 时间排序（升序）
    const sorted = rawData.sort((a, b) => new Date(a.day) - new Date(b.day));

    // 🧡 2. 清空原始数据
    sevendays.value = [];
    data2.value = [];

    // 🧡 3. 补0格式化日期
    sorted.forEach((item) => {
      const date = new Date(item.day);
      const month = String(date.getMonth() + 1).padStart(2, "0");
      const day = String(date.getDate()).padStart(2, "0");
      sevendays.value.push(`${month}-${day}`);
      data2.value.push(item.count);
    });

    // 🧡 4. 等数据更新后再初始化图表
    await nextTick();
    initChart();
  } catch (error) {
    console.error("Failed to fetch danger data:", error);
  }
}

function initChart() {
  const weekEcharts = document.getElementById("weekEcharts");
  if (!weekEcharts) {
    console.warn("⚠️ weekEcharts DOM 元素未找到！");
    return;
  }

  const oldChart = echarts.getInstanceByDom(weekEcharts);
  if (oldChart) {
    echarts.dispose(weekEcharts);
  }

  const myChart = echarts.init(weekEcharts);

  const handleResize = () => myChart.resize();
  window.addEventListener("resize", handleResize);
  onUnmounted(() => window.removeEventListener("resize", handleResize));

  const option = {
    color: ["#ec9335"],
    title: {
      text: "隐患数量周变化",
      textStyle: {
        fontSize: 18,
        fontWeight: 400,
        color: "#303438",
        textShadowBlur: 1.3,
      },
    },
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "cross",
        label: {
          backgroundColor: "#6a7985",
        },
      },
    },
    legend: {
      icon: "roundRect",
      itemGap: 25,
      textStyle: {
        color: "#000",
        fontSize: 15,
      },
      data: ["最近7天"],
      selectedMode: "single",
    },
    toolbox: {
      feature: {
        saveAsImage: {},
      },
      right: "2%",
    },
    grid: {
      left: "2%",
      right: "3%",
      bottom: "0%",
      containLabel: true,
    },
    xAxis: [
      {
        type: "category",
        boundaryGap: false,
        data: sevendays.value,
        axisLabel: {
          interval: 0,
          rotate: 0,
          fontSize: 12.5,
        },
      },
    ],
    yAxis: [
      {
        type: "value",
        axisLabel: {
          fontSize: 12.5,
        },
      },
    ],
    series: [
      {
        name: "最近7天",
        type: "line",
        smooth: true,
        lineStyle: {
          width: 3,
        },
        showSymbol: false,
        areaStyle: {
          opacity: 0.3,
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: "#ec9335" },
            { offset: 1, color: "#ec933569" },
          ]),
        },
        emphasis: {
          focus: "series",
        },
        data: data2.value,
      },
    ],
  };

  myChart.setOption(option);
}

onMounted(() => {
  get();
});
</script>

<style lang="scss" scoped>
</style>
