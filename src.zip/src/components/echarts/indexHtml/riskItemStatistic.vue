<template>
  <div id="indexEcharts" style="width: 100%; height: 340px"></div>
</template>
<script setup>
import { onMounted } from "vue";
import * as echarts from "echarts";
import { get12, get30 } from "@/api/risk/riskPend";
const data1 = ref([]);
const last12Months = ref([]);
const data2 = ref([]);
const last30Days = ref([]);
async function get1230() {
  try {
    const response12 = await get12();
    const response30 = await get30();
    data1.value = last12Months.value.map((month) => {
      const monthData = response12.data.find((data) => data.date === month);
      return monthData ? monthData.count : 0;
    });

    data2.value = last30Days.value.map((day) => {
      const dayData = response30.data.find((data) => data.day === day);
      return dayData ? dayData.count : 0;
    });
    initChart();
  } catch (error) {
    console.error("Failed to fetch danger data:", error);
  }
}
function initChart() {
  const riskItemStatisticEcharts = document.getElementById("indexEcharts");
  if (riskItemStatisticEcharts) {
    const myChart = echarts.init(riskItemStatisticEcharts);
    const handleResize = () => {
      myChart.resize();
    };
    window.addEventListener("resize", handleResize);
    onUnmounted(() => {
      window.removeEventListener("resize", handleResize);
    });

    const option = {
      color: ["#00DDFF", "#80FFA5"],
      title: {
        text: "风险项统计",
        textStyle: {
          fontSize: 17.5,
          fontWeight: 400,
          color: "#07111d",
          textShadowColor: "#07111d",
          textShadowOffsetX: 0,
          textShadowOffsetY: 0,
          textShadowBlur: 1.3,
        },
      },
      tooltip: {
        trigger: "axis",
        axisPointer: {
          type: "cross",
          label: {
            backgroundColor: "#6a7985",
          },
        },
      },
      legend: {
        icon: "roundRect",
        itemGap: 25, // 图例项之间的间隙
        textStyle: {
          color: "#000", // 文字颜色
          fontSize: 14, // 文字大小
        },
        data: ["最近12个月", "最近30天"],
        selected: {},
        selectedMode: "single",
      },
      toolbox: {
        feature: {
          saveAsImage: {},
        },
        right: "2%",
      },
      grid: {
        left: "1%",
        right: "4%",
        bottom: "3%",
        containLabel: true,
      },
      xAxis: [
        {
          type: "category",
          boundaryGap: false,
          data: getMonthsInCurrentYear(),
          axisLabel: {
            interval: 0,
            rotate: 0,
            fontSize: 12.5,
          },
        },
      ],
      yAxis: [
        {
          type: "value",
          axisLabel: {
            fontSize: 12.5,
          },
        },
      ],
      series: [
        {
          name: "最近12个月",
          type: "line",
          smooth: true,
          lineStyle: {
            width: 3,
          },
          showSymbol: false,
          areaStyle: {
            opacity: 0.3,
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "rgb(0, 221, 255)",
              },
              {
                offset: 1,
                color: "rgb(77, 119, 255)",
              },
            ]),
          },
          emphasis: {
            focus: "series",
          },
          data: data1.value,
        },
        {
          name: "最近30天",
          type: "line",
          smooth: true,
          lineStyle: {
            width: 3,
          },
          showSymbol: false,
          areaStyle: {
            opacity: 0.3,
            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
              {
                offset: 0,
                color: "rgb(128, 255, 165)",
              },
              {
                offset: 1,
                color: "rgb(1, 191, 236)",
              },
            ]),
          },
          emphasis: {
            focus: "series",
          },
          data: data2.value,
        },
      ],
    };
    option && myChart.setOption(option);

    // 监听图例变化
    myChart.on("legendselectchanged", function (params) {
      var selected = params.selected;
      var newOption = {};

      if (selected["最近12个月"]) {
        newOption.xAxis = [
          {
            type: "category",
            boundaryGap: false,
            data: getMonthsInCurrentYear(),
            axisLabel: {
              interval: 0,
              rotate: 0,
            },
          },
        ];
      } else if (selected["最近30天"]) {
        var currentDate = new Date();
        var currentMonth = currentDate.getMonth() + 1; // 月份从1开始计数
        var formattedDays = getFormattedDaysInCurrentMonth(currentMonth);
        newOption.xAxis = [
          {
            type: "category",
            boundaryGap: false,
            data: formattedDays,
            axisLabel: {
              interval: 1, // 默认间隔为0，表示全部显示
              rotate: 0, // 旋转角度，使标签更易读
            },
          },
        ];
      }

      // 更新图表配置
      myChart.setOption(newOption);
    });
  }
}
// 获取当前月份的每一天
function getFormattedDaysInCurrentMonth(month) {
  const days = [];
  const lookdays = [];
  var today = new Date();
  var year = today.getFullYear();
  var firstDay = new Date(year, month - 1, 1);
  var lastDay = new Date(year, month, 0); // 获取当月最后一天
  for (var day = 1; day <= lastDay.getDate(); day++) {
    days.push(
      year +
        "-" +
        (month < 10 ? "0" : "") +
        month +
        "-" +
        (day < 10 ? "0" : "") +
        day
    );
    lookdays.push(month + "-" + (day < 10 ? "0" : "") + day);
  }
  last30Days.value = days;
  return lookdays;
}
// 获取当前年份的12个月
function getMonthsInCurrentYear() {
  var today = new Date();
  const months = [];
  var year = today.getFullYear();
  for (var i = 1; i <= 12; i++) {
    months.push(year + "-" + (i < 10 ? "0" : "") + i);
  }
  last12Months.value = months;
  return months;
}
onMounted(() => {
  get1230();
  getMonthsInCurrentYear();
  getFormattedDaysInCurrentMonth(new Date().getMonth() + 1);
});
</script>