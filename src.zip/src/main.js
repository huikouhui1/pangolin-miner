import { createApp } from 'vue'
import Cookies from 'js-cookie'
import VueAMap from 'vue-amap'

import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import locale from 'element-plus/es/locale/lang/zh-cn'

import '@/assets/styles/index.scss'

import App from './App'
import store from './store'
import router from './router'
import directive from './directive'
import plugins from './plugins'
import { download } from '@/utils/request'

import 'virtual:svg-icons-register'
import SvgIcon from '@/components/SvgIcon'
import elementIcons from '@/components/SvgIcon/svgicon'

import './permission'

import { useDict } from '@/utils/dict'
import { parseTime, resetForm, addDateRange, handleTree, selectDictLabel, selectDictLabels } from '@/utils/ruoyi'

import Pagination from '@/components/Pagination'
import RightToolbar from '@/components/RightToolbar'
import Editor from "@/components/Editor"
import FileUpload from "@/components/FileUpload"
import ImageUpload from "@/components/ImageUpload"
import ImagePreview from '@/components/ImagePreview'
import TreeSelect from '@/components/TreeSelect'
import DictTag from '@/components/DictTag'

// ========== Mars3D 导入（放在这里）==========
// import 'mars3d-cesium/Build/Cesium/Widgets/widgets.css'
// import * as Cesium from 'mars3d-cesium/Build/Cesium/Cesium.js'
// import * as mars3d from 'mars3d/mars3d.js'
// import 'mars3d/mars3d.css'
// window.Cesium = Cesium
// window.mars3d = mars3d
// ==========================================

// 只创建一次 app
const app = createApp(App)

// 全局方法挂载
app.config.globalProperties.useDict = useDict
app.config.globalProperties.download = download
app.config.globalProperties.parseTime = parseTime
app.config.globalProperties.resetForm = resetForm
app.config.globalProperties.handleTree = handleTree
app.config.globalProperties.addDateRange = addDateRange
app.config.globalProperties.selectDictLabel = selectDictLabel
app.config.globalProperties.selectDictLabels = selectDictLabels

// 全局组件挂载
app.component('DictTag', DictTag)
app.component('Pagination', Pagination)
app.component('TreeSelect', TreeSelect)
app.component('FileUpload', FileUpload)
app.component('ImageUpload', ImageUpload)
app.component('ImagePreview', ImagePreview)
app.component('RightToolbar', RightToolbar)
app.component('Editor', Editor)

app.use(VueAMap)
app.use(router)
app.use(store)
app.use(plugins)
app.use(elementIcons)
app.component('svg-icon', SvgIcon)
directive(app)

// 使用 element-plus
app.use(ElementPlus, {
  locale: locale,
  size: Cookies.get('size') || 'default'
})

// 只挂载一次
app.mount('#app')